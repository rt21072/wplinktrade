<?php
/**
 * WPLinkTrade Emails Class which handles the email sending.
 *
 * @author    Daniel Bakovic
 * @category  Class
 * @package   WPLinkTrade/Classes/Emails
 */
class WPLinkTrade_Emails {

  /**
   * Get from name for email.
   *
   * @access public
   * @return string
   */
  public function get_from_name() {
    return apply_filters( 'wplinktrade_email_from_name', wp_specialchars_decode ( get_bloginfo('name') ) );
  }

  /**
   * Get from email address.
   *
   * @access public
   * @return string
   */
  public function get_from_address() {
    return apply_filters( 'wplinktrade_email_from_email', get_option('admin_email') );
  }

  /**
   * Filter Email Type.
   *
   * @access public
   * @return string Email content type
   */
  public function get_content_type() {
    return "text/html";
  }

  /**
   * Send the email.
   *
   * @access public
   * @param mixed $to
   * @param mixed $subject
   * @param mixed $message
   * @return void
   */
  public function send( $to, $subject, $message ) {

    // Filters for the email
    add_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
    add_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
    add_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );

    // Send
    wp_mail( $to, $subject, $message, "Content-Type: text/html\r\n" );

    // Unhook filters
    remove_filter( 'wp_mail_from', array( $this, 'get_from_address' ) );
    remove_filter( 'wp_mail_from_name', array( $this, 'get_from_name' ) );
    remove_filter( 'wp_mail_content_type', array( $this, 'get_content_type' ) );
  }

  /**
   * Sends admin notification email
   *
   * @access public
   * @return void
   */
  public function notify_admin() {
    global $wplt;

    $blogname = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );

    $edit_link = '<a href="'.admin_url( 'post.php?post='.$wplt->get_detail('id').'&action=edit' ).'">'.__("Edit Submission", 'wplinktrade').'</a>';

    $message = sprintf( __( 'New link partner submission on your site %s!', 'wplinktrade' ), $blogname ) . "\r\n\r\n";
    $message .= '
      <table>
        <tr>
          <td>'.__('Site URL', 'wplinktrade').'</td>
          <td><a href="'.$wplt->get_detail('site_url').'">'.$wplt->get_detail('site_url').'</a></td>
        </tr>
        <tr>
          <td>'.__('Site Name', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('site_name').'</td>
        </tr>
        <tr>
          <td>'.__('Partner Name', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('contact_name').'</td>
        </tr>
        <tr>
          <td>'.__( 'Partner Email', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('contact_email').'</td>
        </tr>
      </table>
    ';

    $message .= sprintf( __( 'Please visit the moderation panel to review your submissions: %s', 'wplinktrade' ), $edit_link );

    // Allow users to edit the notification message
    $message = apply_filters( 'wplinktrade_admin_notification_message', $message );
    $subject = apply_filters( 'wplinktrade_admin_notification_subject', sprintf( __("[%s] | New Link Submission", 'wplinktrade') , $blogname) );
    $to      = get_option( 'admin_email' );

    // Send email
    $this->send( $to, $subject, $message );
  }

  /**
   * Sends user notification email
   *
   * @access public
   * @return void
   */
  public function notify_partner() {
    global $wplt;

    $blogname = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );

    $message  = sprintf( __( 'Your link has been successfully submitted to our site %s:', 'wplinktrade' ), $blogname ) . "\r\n\r\n";
    
    $message .= __( 'Your link submission details:', 'wplinktrade' ) . "\r\n\r\n";
    
    $message .= '
      <table>
        <tr>
          <td>'.__('Site URL', 'wplinktrade').'</td>
          <td><a href="'.$wplt->get_detail('site_url').'">'.$wplt->get_detail('site_url').'</a></td>
        </tr>
        <tr>
          <td>'.__('Site Name', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('site_name').'</td>
        </tr>
        <tr>
          <td>'.__('Partner Name', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('contact_name').'</td>
        </tr>
        <tr>
          <td>'.__( 'Partner Email', 'wplinktrade').'</td>
          <td>'.$wplt->get_detail('contact_email').'</td>
        </tr>
      </table>
    ' . "\r\n\r\n";
    
    $message .= __( 'We will review your submission as soon as possible!', 'wplinktrade' ) . "\r\n\r\n";

    /*if ( $wplt->get_setting( 'allow_edit' ) == 'yes' ) {
      $message .= sprintf( __('Use this URL to edit your partner link: %s', 'wplinktrade' ), $wplt->get_detail( 'edit_link' ) ) . "\r\n";
    }*/

    // Allow users to edit the notification message
    $message = apply_filters( 'wplinktrade_admin_notification_message', $message );
    $subject = apply_filters( 'wplinktrade_admin_notification_subject', sprintf( __("[%s] | Your Link Submission", 'wplinktrade') , $blogname) );
    $to      = $wplt->get_detail('contact_email');

    // Send email
    $this->send( $to, $subject, $message );
  }

  /**
   * Sends out backlink reports
   *
   * @access public
   * @param array Array with partner data (name, url, reciprocal_link, result, edit_link)
   * @return void
   */
  public function send_report( $data = array() ) {

    if ( empty( $data ) ) return false;

    $report_table = "
    <table>
      <thead>
        <tr>
          <th>". __("Partner Link", 'wplinktrade')."</th>
          <th>". __("Edit Partner", 'wplinktrade')."</th>
          <th>". __("Check Result", 'wplinktrade')."</th>
        </tr>
      </thead>
      <tbody>";

    foreach ( $data as $partner ) {
      $report_table .= '
        <tr>
          <td><a href="'.$partner['url'].'">'.$partner['name'].'</a></td>
          <td><a href="'.$partner['edit_link'].'">'.__("Edit", 'wplinktrade').'</a></td>
          <td>'.$partner['result'].'</td>
        </tr>
      ';
    }

    $report_table .= "
      </tbody>
    </table>";

    $message = __("Hi!", 'wplinktrade')
      . "<br /><br />"
      . __("This is your WPLinkTrade Backlink Check Report. Bellow is a list of your partners with failed backlink check!", 'wplinktrade')
      . "<br /><br />" . "\r\n\r\n"
      . $report_table;

    $blogname = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );

    // Allow users to edit the notification message
    $message = apply_filters( 'wplinktrade_admin_report_message', $message );
    $subject = apply_filters( 'wplinktrade_admin_report_subject', sprintf( __("[%s] | Backlink check report", 'wplinktrade') , $blogname) );
    $to      = get_option( 'admin_email' );

    // Send email
    $this->send( $to, $subject, $message );
  }
}