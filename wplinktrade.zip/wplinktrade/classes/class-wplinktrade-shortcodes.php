<?php
/**
 * WPLinkTrade Shortcode Class
 *
 * @class WPLinkTrade_Shortcodes
 * @package WPLinkTrade/Classes
 * @author Daniel Bakovic
 */

class WPLinkTrade_Shortcodes {

  /**
   * __construct
   *
   * @version 1.4.0
   * @since   1.0.0
   * @access  public
   * @return  void
   */
  public function __construct() {

    add_action( 'admin_head', array( $this, 'add_shortcode_button') );
    add_action( 'admin_enqueue_scripts', array( $this, 'css' ) );

    // Register shortcodes
    add_shortcode( 'wplinktrade_stats',  array( $this, 'stats') );
    add_shortcode( 'wplinktrade_list',  array( $this, 'linklist') );
    add_shortcode( 'wplinktrade_submit_step_1', array( $this, 'submit_step_1') );
    add_shortcode( 'wplinktrade_submit', array( $this, 'form') );
  }

  /**
   * Adds a shortcode button to TinyMCE
   *
   * @version 1.0.0
   * @since   1.0.0
   * @access public
   * @return void
   */
  public function add_shortcode_button() {
    if ( ! current_user_can('edit_posts') && ! current_user_can('edit_pages') ) return;

    if ( get_user_option('rich_editing') == 'true' )  {
      add_filter('mce_external_plugins', array( $this, 'add_shortcode_tinymce_plugin' ) );
      add_filter('mce_buttons', array( $this, 'register_shortcode_button' ) );
    }
  }

  /**
   * Add our MCE Button
   *
   * @version 1.4.0
   * @since   1.0.0
   * @param   array $buttons
   * @return  array
   */
  public function register_shortcode_button( $buttons ) {
    array_push( $buttons, "wplts");
    return $buttons;
  }

  /**
   * Register our MCE plugin
   *
   * @version 1.4.0
   * @since   1.0.0
   * @param   array $plugin_array
   */
  public function add_shortcode_tinymce_plugin( $plugin_array ) {
    global $wplt;

    $plugin_array['wplts'] = $wplt->plugin_url . 'assets/js/editor_plugin.js';
    return $plugin_array;
  }

  /**
   * Add css for the tinymce menu icon
   *
   * @version 1.4.0
   * @since   1.4.0
   * @return  void
   */
  public function css() {
    global $wplt;
    wp_enqueue_style( 'wplt-mce-css',  $wplt->plugin_url . 'assets/css/wplt_mce.css' );
  }

  /**
   * Display a table with partner links. It handles text and image lists
   *
   * @version 1.5.0
   * @since   1.0.0
   * @access public
   * @return void
   */
  public function stats( $atts ) {

    $defaults = array(
      'count'   => -1,
      'orderby' => 'total_in',
      'order'   => 'DESC',
      'type'    => 'text',
      'category'=> false,
    );

    $atts = wp_parse_args( $atts, $defaults );

    switch ( $atts['orderby'] ) {
      case 'total_in':
      case 'total_out':
      case 'today_in':
      case 'today_out': {
        $orderby  = 'meta_value_num';
        $meta_key = $atts['orderby'];
      } break;

      default : {
        $orderby  = $atts['orderby'];
        $meta_key = false;
      } break;
    }

    $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

    $query_args = array(
      'post_type'   => 'linktrade',
      'posts_per_page' => $atts['count'],
      'paged'       => $paged,
      'order'       => $atts['order'],
      'orderby'     => $orderby,
      'meta_key'    => $meta_key,
      'meta_query'  => array(
        array(
          'key'     =>  'link_type',
          'value'   =>  $atts['type'],
          'compare' => 'LIKE'
        )
      )
    );

    if ( intval( $atts['category'] ) > 0 && taxonomy_exists( 'linktrade_cat' ) ) {
      $query_args['tax_query'] = array(
        array(
          'taxonomy' => 'linktrade_cat',
          'terms' => $atts['category'],
          'field' => 'term_id',
        )
      );
    }

    query_posts( $query_args );

    ob_start();

    if ( have_posts() ) {

      wplinktrade_list_loop_start();

      while ( have_posts() ) : the_post();
        wplinktrade_get_template_part( 'content', 'link_'.$atts['type'] );
      endwhile;

      wplinktrade_list_loop_end();

      do_action( 'wplinktrade_after_loop' );
    }

    wp_reset_query();

    return '<div class="wplinktrade">' . ob_get_clean() . '</div>';
  }

  /**
   * Display a table with partner links and descriptions.
   *
   * @version 1.4.0
   * @since   1.0.0
   * @access public
   * @return void
   */
  public function linklist( $atts ) {

    $defaults = array(
      'count'     => -1,
      'orderby'   => 'total_in',
      'order'     => 'DESC',
      'type'      => 'text',
      'category'  => false,
    );

    $atts = wp_parse_args( $atts, $defaults );

    switch ( $atts['orderby'] ) {
      case 'total_in':
      case 'total_out':
      case 'today_in':
      case 'today_out': {
        $orderby  = 'meta_value_num';
        $meta_key = $atts['orderby'];
      } break;

      default : {
        $orderby  = $atts['orderby'];
        $meta_key = false;
      } break;
    }

    $paged = ( get_query_var('paged') ) ? get_query_var('paged') : 1;

    $query_args = array(
      'post_type'   => 'linktrade',
      'posts_per_page' => $atts['count'],
      'paged'       => $paged,
      'order'       => $atts['order'],
      'orderby'     => $orderby,
      'meta_key'    => $meta_key,
      'meta_query'  => array(
        array(
          'key'     =>  'link_type',
          'value'   =>  $atts['type'],
          'compare' => 'LIKE'
        )
      )
    );

    if ( intval( $atts['category'] ) > 0 && taxonomy_exists( 'linktrade_cat' ) ) {
      $query_args['tax_query'] = array(
        array(
          'taxonomy' => 'linktrade_cat',
          'terms' => $atts['category'],
          'field' => 'term_id',
        )
      );
    }

    query_posts( $query_args );

    ob_start();

    if ( have_posts() ) {

      $loop_start = '<div class="wplinktrade_stats wplinktrade_links">
      <table class="stats_table" callspacing="1">
      <thead>
      <tr>
        <th>' . __("Site", 'wplinktrade') . '</th>
        <th>' . __("Description", 'wplinktrade') . '</th>';

      $loop_end = '</tbody></table></div>';

      echo apply_filters( 'wplinktrade_linklist_loop_start', $loop_start);

      while ( have_posts() ) : the_post();
        wplinktrade_get_template_part( 'content', 'linklist_'.$atts['type'] );
      endwhile;

      echo apply_filters( 'wplinktrade_linklist_loop_end', $loop_end );

      do_action( 'wplinktrade_after_loop' );
    }

    wp_reset_query();

    return '<div class="wplinktrade">' . ob_get_clean() . '</div>';
  }

  public function submit_step_1( $atts ) {
    // We don't need any $atts on this shortcode
    ob_start();
    wplinktrade_get_template_part( 'content', 'submit_step_1' );
    return '<div class="wplinktrade_step_1">' . ob_get_clean() . '</div>';
  }

  public function form( $atts ) {
    // We don't need any $atts on this shortcode
    ob_start();
    wplinktrade_get_template_part( 'content', 'submit_form' );
    return '<div class="wplinktrade_form">' . ob_get_clean() . '</div>';
  }
}