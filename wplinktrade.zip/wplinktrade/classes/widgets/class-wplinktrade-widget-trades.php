<?php
/**
 * Link Trade Widget
 *
 * Displays text links or banner trades
 *
 * @author    Daniel Bakovic
 * @category  Widgets
 * @package   WPLinkTrade/Widgets
 * @extends   WP_Widget
 */
class WPLinkTrade_Widget_Trades extends WP_Widget {

    var $widget_cssclass;
    var $widget_description;
    var $widget_idbase;
    var $widget_name;

  /**
   * constructor
   *
   * @access public
   * @return void
   */
  function __construct() {

    /* Widget variable settings. */
    $this->widget_cssclass    = 'wplinktrade trades-widget';
    $this->widget_description = __( "Display the WPLinkTrade links / banners in the sidebar.", 'wplinktrade' );
    $this->widget_idbase      = 'wplinktrade_widget_trades';
    $this->widget_name        = __( 'Link / Banner Trades', 'wplinktrade' );

    /* Widget settings. */
    $widget_ops = array( 'classname' => $this->widget_cssclass, 'description' => $this->widget_description );

    /* Create the widget. */
    parent::__construct( 'wplinktrade_links', $this->widget_name, $widget_ops );
  }

  /**
   * widget function.
   *
   * @see WP_Widget
   * @access public
   * @param array $args
   * @param array $instance
   * @return void
   */
  function widget( $args, $instance ) {

    extract( $args );

    $title        = !empty( $instance['title'] ) ? $instance['title'] : '';
    $orderby_key  = !empty( $instance['link_orderby'] ) ? $instance['link_orderby'] : 'total_in';
    $link_type    = !empty( $instance['link_type'] ) ? $instance['link_type'] : 'text';
    $width        = !empty( $instance['banner_width'] ) ? $instance['banner_width'] : 100;
    $height       = !empty( $instance['banner_height']) ? $instance['banner_height'] : 100;

    switch ( $orderby_key ) {
      /* Meta field orderby */
      case 'total_in' :
      case 'total_out' :
      case 'today_in' :
      case 'today_out' : {
        $orderby  = 'meta_value_num';
        $meta_key = $orderby_key;
      } break;

      /* Default WordPress orderby possiblities */
      default : {
        $orderby = $orderby_key;
        $meta_key = '';
      } break;
    }

    $args = array(
      'post_type'   => 'linktrade',
      'post_status' => 'publish',
      'posts_per_page' => !empty( $instance['link_count'] ) ? (int) $instance['link_count'] : 4,
      'order'       => !empty( $instance['link_order'] ) ? $instance['link_order'] : 'DESC',
      'orderby'     => $orderby,
      'meta_key'    => $meta_key,
      'meta_query'  => array(
        array(
          'key'     =>  'link_type',
          'value'   =>  $link_type,
          'compare' => 'LIKE'
        )
      )
    );

    $tradelinks = new WP_Query( $args );

    if ( $tradelinks->have_posts() ) {

      echo $before_widget;

      if ( $title )
        echo $before_title . $title . $after_title;

      echo '<ul class="wplinktrade_widget_'.$link_type.' wplinktrade_links">';

      while ( $tradelinks->have_posts() ) {
        $tradelinks->the_post();

        switch ( $link_type ) {
          case 'text' : {
            echo '<li>' . wplinktrade_get_link() . '</li>';
          } break;

          case 'image' : {
            $banner_link = wplinktrade_get_banner( $width, $height );

            if ( $banner_link ) {
              echo '<li>' . $banner_link . '</li>';
            }

          } break;
        }
      }
    }

    wp_reset_postdata();

    echo '</ul><div style="clear:both"></div>';

    echo $after_widget;
  }

  /**
   * update function.
   *
   * @see WP_Widget->update
   * @access public
   * @param array $new_instance
   * @param array $old_instance
   * @return array
   */
  function update( $new_instance, $old_instance ) {

    $instance = array();
    $instance['title']          =  isset( $new_instance['title'] ) ? strip_tags( $new_instance['title'] ) : '';
    $instance['link_type']      =  isset( $new_instance['link_type'] ) ? $new_instance['link_type'] : 'text';
    $instance['link_count']     =  isset( $new_instance['link_count'] ) ? (int) $new_instance['link_count'] : 4;
    $instance['link_order']     =  isset( $new_instance['link_order'] ) ? $new_instance['link_order'] : 'DESC';
    $instance['link_orderby']   =  isset( $new_instance['link_orderby'] ) ? $new_instance['link_orderby'] : 'total_in';
    $instance['banner_width']   =  isset( $new_instance['banner_width'] ) ? $new_instance['banner_width'] : 100;
    $instance['banner_height']  =  isset( $new_instance['banner_height'] ) ? $new_instance['banner_height'] : 100;

    return $instance;
  }

  /**
   * form function.
   *
   * @see WP_Widget->form
   * @access public
   * @param array $instance
   * @return void
   */
  function form( $instance ) {

    $instance = wp_parse_args( (array) $instance, array(
        'title'         => __('Our partners', 'wplinktrade'),
        'link_type'     => 'text',
        'link_count'    => 4,
        'link_order'    => 'DESC',
        'link_orderby'  => 'total_out',
        'banner_width'  => 100,
        'banner_height' => 100
      )
    );
    ?>
    <p>
      <label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title', 'wplinktrade' ) ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" value="<?php if (isset ( $instance['title'])) {echo esc_attr( $instance['title'] );} ?>" />
    </p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('link_type') ); ?>"><?php _e('Link Type', 'wplinktrade'); ?></label>
      <select id="<?php echo esc_attr( $this->get_field_id('link_type') ); ?>" name="<?php echo esc_attr( $this->get_field_name('link_type') ); ?>" class="widefat">
        <option value="text" <?php selected( $instance['link_type'], 'text') ?>><?php _e("Text", 'wplinktrade'); ?></option>
        <option value="image" <?php selected( $instance['link_type'], 'image'); ?>><?php _e("Image", 'wplinktrade'); ?></option>
      </select>
    </p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('link_count') ); ?>"><?php _e("Number of partners to show"); ?> </label>
      <input type="text" id="<?php echo esc_attr( $this->get_field_id('link_count') ); ?>" name="<?php echo esc_attr( $this->get_field_name('link_count') ); ?>" value="<?php if ( isset ( $instance['link_count'] ) ) { echo esc_attr( $instance['link_count'] ); } ?>" class="widefat" />
    </p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('link_order') ); ?>"><?php _e("Link Order", 'wplinktrade' ); ?></label>
      <select class="widefat" id="<?php echo esc_attr( $this->get_field_id('link_order') ); ?>" name="<?php echo esc_attr( $this->get_field_name('link_order') ); ?>">
        <option value="ASC" <?php selected( $instance['link_order'], 'ASC'); ?>><?php _e("Ascending", 'wplinktrade'); ?></option>
        <option value="DESC" <?php selected( $instance['link_order'], 'DESC'); ?>><?php _e("Descending", 'wplinktrade'); ?></option>
      </select>
    </p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('link_orderby') ); ?>"><?php _e("Order by", 'wplinktrade' ); ?></label>
      <select class="widefat" id="<?php echo esc_attr( $this->get_field_id('link_orderby') ); ?>" name="<?php echo esc_attr( $this->get_field_name('link_orderby') ); ?>">
        <option value="ID" <?php selected( $instance['link_orderby'], 'ID'); ?>><?php _e("Partner ID", 'wplinktrade'); ?></option>
        <option value="title" <?php selected( $instance['link_orderby'], 'title'); ?>><?php _e("Partner Name", 'wplinktrade'); ?></option>
        <option value="date" <?php selected( $instance['link_orderby'], 'date'); ?>><?php _e("Date added", 'wplinktrade'); ?></option>
        <option value="today_in" <?php selected( $instance['link_orderby'], 'today_in'); ?>><?php _e("Today In", 'wplinktrade'); ?></option>
        <option value="today_out" <?php selected( $instance['link_orderby'], 'today_out'); ?>><?php _e("Today Out", 'wplinktrade'); ?></option>
        <option value="total_in" <?php selected( $instance['link_orderby'], 'total_in'); ?>><?php _e("Total In", 'wplinktrade'); ?></option>
        <option value="total_out" <?php selected( $instance['link_orderby'], 'total_out'); ?>><?php _e("Total Out", 'wplinktrade'); ?></option>
        <option value="rand" <?php selected( $instance['link_orderby'], 'rand'); ?>><?php _e("Random", 'wplinktrade'); ?></option>
      </select>
    </p>

    <p><?php _e("Banner size if link type is image", 'wplinktrade'); ?></p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('banner_width') ); ?>"><?php _e('Banner Width (in px)', 'wplinktrade'); ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('banner_width') ); ?>" name="<?php echo esc_attr( $this->get_field_name('banner_width') ); ?>" value="<?php echo $instance['banner_width']; ?>" />
    </p>

    <p>
      <label for="<?php echo esc_attr( $this->get_field_id('banner_height') ); ?>"><?php _e('Banner Height (in px)', 'wplinktrade'); ?></label>
      <input type="text" class="widefat" id="<?php echo esc_attr( $this->get_field_id('banner_height') ); ?>" name="<?php echo esc_attr( $this->get_field_name('banner_height') ); ?>" value="<?php echo $instance['banner_height']; ?>" />
    </p>
    <?php
  }
}