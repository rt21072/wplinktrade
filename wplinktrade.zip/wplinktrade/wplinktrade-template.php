<?php
/**
 * WPLinkTrade Template Functions
 *
 * Functions used in the template files to output content - in most cases hooked in via the template actions.
 * All functions are pluggable.
 *
 * @author    Daniel Bakovic
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

if ( ! function_exists('wplinktrade_list_loop_start') ) {
  function wplinktrade_list_loop_start( $echo = true ) {
    ob_start();
    wplinktrade_get_template( 'loop/list-loop-start.php' );
    if ( $echo )
      echo ob_get_clean();
    else
      return ob_get_clean();
  }
}

if ( ! function_exists('wplinktrade_list_loop_end') ) {
  function wplinktrade_list_loop_end( $echo = true ) {
    ob_start();
    wplinktrade_get_template( 'loop/list-loop-end.php' );
    if ( $echo )
      echo ob_get_clean();
    else
      return ob_get_clean();
  }
}

/**
 * Get the requested template file
 */
function wplinktrade_get_template( $template_name, $args = array(), $template_path = '', $default_path = ''  ) {
  global $wplt;

  if ( $args && is_array($args) )
    extract( $args );

  $located = wplinktrade_locate_template( $template_name, $template_path, $default_path );

  do_action( 'wplinktrade_before_template_part', $template_name, $template_path, $located );

  include( $located );

  do_action( 'wplinktrade_after_template_part', $template_name, $template_path, $located );
}

/**
 * Locate a template and return the path for inclusion
 *
 * This is the load order:
 *
 *    yourtheme   / $template_path  / $template_name
 *    yourtheme   / $template_name
 *    $default_path / $template_name
 */
function wplinktrade_locate_template(  $template_name, $template_path = '', $default_path = '' ) {
  global $wplt;

  if ( ! $template_path ) $template_path = $wplt->template_url;
  if ( ! $default_path ) $default_path = $wplt->plugin_dir . '/templates/';

  // Look within passed path within the theme - this is priority
  $template = locate_template(
    array(
      trailingslashit( $template_path ) . $template_name,
      $template_name
    )
  );

  // Get default template
  if ( ! $template )
    $template = $default_path . $template_name;

  // Return what we found
  return apply_filters( 'wplinktrade_locate_template', $template, $template_name, $template_path );
}

/**
 * Get template part
 **/
function wplinktrade_get_template_part( $slug, $name = '' ) {
  global $wplt;

  $template = '';

  // Look in yourtheme/slug-name.php and yourtheme/wplinktrade/slug-name.php
  if ( $name )
    $template = locate_template( array ( "{$slug}-{$name}.php", "{$wplt->template_url}{$slug}-{$name}.php" ) );

  // Get default slug-name.php
  if ( !$template && $name && file_exists( $wplt->plugin_dir . "/templates/{$slug}-{$name}.php" ) )
    $template = $wplt->plugin_dir . "/templates/{$slug}-{$name}.php";

  // If template file doesn't exist, look in yourtheme/slug.php and yourtheme/wplinktrade/slug.php
  if ( !$template )
    $template = locate_template( array ( "{$slug}.php", "{$wplt->template_url}{$slug}.php" ) );

  if ( $template )
    load_template( $template, false );
}

/**
 * Display a pagination bellow link lists
 *
 * @version 1.4.0
 * @since   1.4.0
 * @return  void
 */
function wplinktrade_pagination() {
  global $wp_query;

  $total_pages = $wp_query->max_num_pages;

  if ($total_pages > 1) {

    ?>
    <div class="wplinktrade_navigation">
      <?php
      $current_page = max(1, get_query_var('paged'));

      echo paginate_links( array(
          'base' => get_pagenum_link(1) . '%_%',
          'format' => 'page/%#%',
          'current' => $current_page,
          'total' => $total_pages,
        )
      );
      ?>
    </div>
    <?php
  }
}
add_action( 'wplinktrade_after_loop', 'wplinktrade_pagination' );