<?php
/**
 * WPLinkTrade Admin
 *
 * Main admin file which loads all settings panels and sets up admin menus.
 *
 * @author    Daniel Bakovic
 * @category  Admin
 * @package   WPLinkTrade/Admin
 */


/**
 * Setup the admin menu in WordPress
 *
 */
function wplinktrade_admin_menu() {
  global $wplt;

  add_submenu_page(
    'edit.php?post_type=linktrade',
    __('Settings'),
    __('Settings'),
    'manage_options',
    'wplinktrade_settings_page',
    'wplinktrade_settings_page' );
}
add_action( 'admin_menu' , 'wplinktrade_admin_menu' );


function linktrade_admin_scripts() {
  global $wplt, $typenow, $post;

  if ( $typenow == 'post' && ! empty( $_GET['post'] ) ) {
    $typenow = $post->post_type;
  } elseif ( empty( $typenow ) && ! empty( $_GET['post'] ) ) {
    $post = get_post( $_GET['post'] );
    $typenow = $post->post_type;
  }

  if ( $typenow == '' || $typenow == "linktrade" ) {
    wp_enqueue_style( 'wplinktrade_admin_styles', $wplt->plugin_url . 'assets/css/admin.css' );
  }

}
add_action( 'admin_enqueue_scripts', 'linktrade_admin_scripts' );

/**
 * Define Columns for the Links admin page
 *
 * @param array $columns
 */
function edit_linktrade_columns( $columns ) {
  global $wplt;

  $columns                = array();
  $columns["cb"]          = "<input type=\"checkbox\" />";
  $columns["title"]       = __("Site Name",   'wplinktrade');
  if ( 'yes' == $wplt->get_setting( 'categorize' ) ) {
    $columns["category"]    = __("Category",    'wplinktrade');
  }
  $columns["today_in"]    = __("Today In",    'wplinktrade');
  $columns["today_out"]   = __("Today Out",   'wplinktrade');
  $columns["total_in"]    = __("Total In",    'wplinktrade');
  $columns["total_out"]   = __("Total Out",   'wplinktrade');
  $columns["ratio"]       = __("Ratio",       'wplinktrade');
  //$columns["featured"]    = __("Featured",    'wplinktrade');
  //$columns["pagerank"]    = __("PageRank",    'wplinktrade');
  $columns["backlink"]    = __("Link back", 'wplinktrade');
  /*$columns["expiry_date"] = __("Expiry date", 'wplinktrade');*/
  //$columns["status"]    = __("Status", 'wplinktrade');
  return $columns;
}
add_filter('manage_edit-linktrade_columns', 'edit_linktrade_columns');

/**
 * Values for Columns on the LinkTrade admin page.
 *
 * @access public
 * @param mixed $column
 * @return void
 */
function linktrade_posts_custom_columns( $column ) {
  global $post;

  switch ($column) {

    case "category": {
      $terms = get_the_terms( $post->ID, 'linktrade_cat' );
      if ( $terms ) {
        $term_names = array();
        foreach ( $terms as $term ) {
          $term_names[] = $term->name;
        }
        echo join( ", ", $term_names );
      }
      else {
        echo '-';
      }
    } break;

    case "today_in" :
    case "today_out" :
    case "total_in" :
    case "total_out" :
    /*case "pagerank" : */{
      echo intval( get_post_meta( $post->ID, $column, true ) );
    } break;

    case "ratio" : {
      $ratio = get_post_meta( $post->ID, 'ratio', true );
      if ( ! $ratio ) $ratio = '0';
      echo $ratio . '%';
    } break;

    case 'backlink': {
      $backlink = get_post_meta( $post->ID, 'backlink_found', true);
      if ( $backlink ) _e("Yes", 'wplinktrade'); else echo '<font color="red">' . __("No", 'wplinktrade') . '</font>';
    } break;
  }
}
add_action( 'manage_linktrade_posts_custom_column', 'linktrade_posts_custom_columns', 2 );

/**
 * Filters for the linktrade page.
 *
 * @access public
 * @param mixed $views
 * @return array
 */
function custom_linktrade_views( $views ) {

  unset( $views['publish'] );

  if ( isset( $views['trash'] ) ) {
    $trash = $views['trash'];
    unset( $views['draft'] );
    unset( $views['trash'] );
    $views['trash'] = $trash;
  }

  return $views;
}
add_filter( 'views_edit-linktrade', 'custom_linktrade_views' );

/**
 * Actions for the orders page.
 *
 * @access public
 * @param mixed $actions
 * @return array
 */
function linktrade_remove_row_actions( $actions ) {
  if( get_post_type() === 'linktrade' ) {
    unset( $actions['view'] );
    unset( $actions['inline hide-if-no-js'] );
  }
  return $actions;
}
add_filter( 'post_row_actions', 'linktrade_remove_row_actions' );

/**
 * Remove edit from the bulk actions.
 *
 * @access public
 * @param mixed $actions
 * @return array
 */
function linktrade_bulk_actions( $actions ) {
  if ( isset( $actions['edit'] ) ) {
    unset( $actions['edit'] );
  }

  return $actions;
}
add_filter( 'bulk_actions-edit-linktrade', 'linktrade_bulk_actions' );

/**
 * Make linktrade columns sortable.
 *
 *
 * https://gist.github.com/906872
 *
 * @access public
 * @param mixed $columns
 * @return array
 */
function custom_linktrade_sort( $columns ) {
  $custom = array(
    'title'       => 'ID',
    'today_in'    => 'today_in',
    'today_out'   => 'today_out',
    'total_in'    => 'total_in',
    'total_out'   => 'total_out',
    'ratio'       => 'ratio'/*,
    'pagerank'    => 'pagerank',*/
  );
  unset( $columns['comments'] );
  return wp_parse_args( $custom, $columns );
}
//add_filter( "manage_edit-linktrade_sortable_columns", 'custom_linktrade_sort' );

/**
 * Order column orderby/request.
 *
 * @access public
 * @param mixed $vars
 * @return array
 */
function custom_linktrade_orderby( $vars ) {
  global $typenow, $wp_query;

  if ( $typenow != 'linktrade' )
    return $vars;

  // Sorting
  if ( isset( $vars['orderby'] ) ) {
    if ( 'today_in' == $vars['orderby'] ) {
      $vars = array_merge( $vars, array(
        'meta_key'  => '_today_in',
        'orderby'   => 'meta_value_num'
      ) );
    }
  }

  return $vars;
}
//add_filter( 'request', 'custom_linktrade_orderby' );

function wplinktrade_settings_page() {
  global $wplt;
  include_once( $wplt->plugin_dir .'/admin/settings-page.php' );
  wplinktrade_settings();
}

function wplinktrade_add_button_to_views( $views )
{
  ob_start();
  ?>
  <form action="" name="wplinktrade_check_backlinks" id="wplinktrade_check_backlinks" method="post">
    <?php wp_nonce_field('wplinktrade_link_check_nonce_action','wplinktrade_link_check_nonce_field'); ?>
    <input type="submit" name="wplinktrade_link_check" id="wplinktrade_link_check" class="button" value="Check Back Links" />
  </form>
  <?php
  $views['wplinktrade_link_check'] = ob_get_clean();

  return $views;
}
add_filter( 'views_edit-linktrade', 'wplinktrade_add_button_to_views' );