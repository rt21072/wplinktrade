<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

function linktade_meta_boxes() {
  add_meta_box( 'linktrade-meta-data', __( 'Link Data', 'linktrade' ), 'linktrade_data_meta_box', 'linktrade', 'normal', 'high');
  //add_meta_box( 'linktrade-meta-stats', __( 'Link Stats', 'linktrade' ), 'linktrade_stats_meta_box', 'linktrade');
}
add_action( 'add_meta_boxes', 'linktade_meta_boxes' );

/**
 * Displays the linktrade data meta box.
 *
 * @access public
 * @param mixed $post
 * @return void
 */
function linktrade_data_meta_box() {
  global $post;

  wp_nonce_field( 'linktrade_save_data', 'linktrade_meta_nonce' );

  ?>
  <style type="text/css">
    #edit-slug-box { display:none }
  </style>
  <div id="wplt_settings" class="panel">

     <div class="control-group">
      <label class="control-label" for="site_url"><?php _e("Site URL", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="text" name="site_url" value="<?php echo get_post_meta( $post->ID, 'site_url', true ); ?>" />
        <span class="help-block"><?php _e("Enter the URL of the exchange partner", 'wplinktrade'); ?></span>
      </div>
    </div>
    
     <div class="control-group">
      <label class="control-label" for="site_description"><?php _e("Site Description", 'wplinktrade'); ?></label>
      <div class="controls">
        <textarea id="site_description" name="site_description"><?php echo get_post_meta( $post->ID, 'site_description', true ); ?></textarea>
        <span class="help-block"><?php _e("Enter shot description for the exchange partner site.", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="link_title"><?php _e("Link Title", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="text" id="link_title" name="link_title" value="<?php echo get_post_meta( $post->ID, 'link_title', true ); ?>" />
        <span class="help-block"><?php _e("Enter the link title for the exchange partner site.", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="link_type"><?php _e("Exchange Type", 'wplinktrade'); ?></label>
      <div class="controls">
        <select id="link_type" name="link_type">
          <option value="text" <?php selected( get_post_meta($post->ID, 'link_type', true), 'text'); ?>><?php _e('Text', 'wplinktrade'); ?></option>
          <option value="image" <?php selected( get_post_meta($post->ID, 'link_type', true), 'image'); ?>><?php _e('Image', 'wplinktrade'); ?></option>
        </select>
        <span class="help-block"><?php _e("Select the exchange type for the partner site.", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="reciprocal_link_required"><?php _e("Reciprocal Link Required?", 'wplinktrade'); ?></label>
      <div class="controls">
        <select id="reciprocal_link_required" name="reciprocal_link_required">
          <option value="yes" <?php selected( get_post_meta($post->ID, 'reciprocal_link_required', true), 'yes'); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
          <option value="no" <?php selected( get_post_meta($post->ID, 'reciprocal_link_required', true), 'no'); ?>><?php _e('No', 'wplinktrade'); ?></option>
        </select>
        <span class="help-block"><?php _e("Is a reciprocal link on partner's website required?", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="reciprocal_link"><?php _e("Reciprocal Link Location", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="text" name="reciprocal_link" id="reciprocal_link" value="<?php echo get_post_meta( $post->ID, 'reciprocal_link', true ); ?>" />
        <span class="help-block"><?php _e("If a reciprocal link is required then enter the link location URL.", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="contact_name"><?php _e("Partner Name", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="text" name="contact_name" id="contact_name" value="<?php echo get_post_meta( $post->ID, 'contact_name', true ); ?>" />
        <span class="help-block"><?php _e("Enter the name of your exchange partner (Contact person).", 'wplinktrade'); ?></span>
      </div>
    </div>

     <div class="control-group">
      <label class="control-label" for="contact_email"><?php _e("Partner Email", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="text" name="contact_email" id="contact_email" value="<?php echo get_post_meta( $post->ID, 'contact_email', true ); ?>" />
        <span class="help-block"><?php _e("Enter the email address of your exchange partner (Contact person).", 'wplinktrade'); ?></span>
      </div>
    </div>

  </div>
  <?php
}

function linktrade_stats_meta_box() {

}

/**
 * Save meta boxes
 */
function linktrade_meta_boxes_save( $post_id, $post ) {
  if ( empty( $post_id ) || empty( $post ) ) return;
  if ( $post->post_type != 'linktrade' ) return;
  if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) return;
  if ( is_int( wp_is_post_revision( $post ) ) ) return;
  if ( is_int( wp_is_post_autosave( $post ) ) ) return;
  if ( empty( $_POST['linktrade_meta_nonce'] ) || ! wp_verify_nonce( $_POST['linktrade_meta_nonce'], 'linktrade_save_data' ) ) return;
  if ( !current_user_can( 'edit_post', $post_id )) return;

  $site_url       = isset( $_POST['site_url'] ) ? esc_url_raw( $_POST['site_url'] ) : '';
  $site_description = !empty( $_POST['site_description']) ? esc_textarea( $_POST['site_description'] ) : '';
  $link_title     = isset( $_POST['link_title'] ) ? sanitize_text_field( $_POST['link_title'] ) : '';
  $link_type      = $_POST['link_type'];
  $reciprocal_link = isset( $_POST['reciprocal_link'] ) ? esc_url_raw( $_POST['reciprocal_link'] ) : '';
  $reciprocal_link_required = $_POST['reciprocal_link_required'];
  $contact_name   = isset( $_POST['contact_name'] ) ? sanitize_text_field( $_POST['contact_name'] ) : '';
  $contact_email  = isset( $_POST['contact_email'] ) ? sanitize_email( $_POST['contact_email'] ) : '';

  update_post_meta( $post_id, 'site_url', $site_url );
  update_post_meta( $post_id, 'link_title', $link_title );
  update_post_meta( $post_id, 'link_type', $link_type );
  update_post_meta( $post_id, 'reciprocal_link', $reciprocal_link );
  update_post_meta( $post_id, 'reciprocal_link_required', $reciprocal_link_required );
  update_post_meta( $post_id, 'contact_name', $contact_name );
  update_post_meta( $post_id, 'contact_email', $contact_email );
  update_post_meta( $post_id, 'site_description', $site_description);
  
  update_post_meta( $post_id, 'today_in', '0');
  update_post_meta( $post_id, 'total_in', '0');
  update_post_meta( $post_id, 'today_out', '0');
  update_post_meta( $post_id, 'total_out', '0');
  update_post_meta( $post_id, 'ratio', '0' );
  update_post_meta( $post_id, 'backlink', false );
}
add_action( 'save_post', 'linktrade_meta_boxes_save', 1, 2 );

/**
 * Change title boxes in admin.
 *
 * @access public
 * @param mixed $text
 * @param mixed $post
 * @return string
 */
function linktrade_enter_title_here( $text, $post ) {
	if ( $post->post_type == 'linktrade' ) return __( 'Site name', 'linktrade' );
	return $text;
}
add_filter('enter_title_here', 'linktrade_enter_title_here', 1, 2);