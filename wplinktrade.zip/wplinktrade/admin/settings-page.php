<?php
/**
 * Settings page
 *
 * @version 1.5.0
 * @since   1.0.0
 * @return  void
 */
 function wplinktrade_settings() {
 	global $wplt;

  if ( !empty( $_POST ) && isset( $_POST['wplt_save_settings'] ) ) {
    $wplt->set_setting( 'admin_notifications',    sanitize_text_field( $_POST['admin_notifications'] ) );
    $wplt->set_setting( 'partner_notifications',  sanitize_text_field( $_POST['partner_notifications'] ) );
    $wplt->set_setting( 'auto_approve',           sanitize_text_field( $_POST['auto_approve'] ) );
    $wplt->set_setting( 'description_required',   sanitize_text_field( $_POST['description_required']) );
    $wplt->set_setting( 'reciprocal',             sanitize_text_field( $_POST['reciprocal'] ) );
    $wplt->set_setting( 'link_target',            sanitize_text_field( $_POST['link_target'] ) );
    $wplt->set_setting( 'relation',               sanitize_text_field( $_POST['relation'] ) );
    $wplt->set_setting( 'categorize',             sanitize_text_field( $_POST['categorize'] ) );
    $exchange_type = array(
      'text'  => !empty( $_POST['exchange_type']['text'] )  ? $_POST['exchange_type']['text']  : false,
      'image' => !empty( $_POST['exchange_type']['image'] ) ? $_POST['exchange_type']['image'] : false
    );
    $wplt->set_setting( 'exchange_type',          $exchange_type );
    $wplt->set_setting( 'banner_height',          !empty ( $_POST['banner_height'] ) ? (int) sanitize_text_field( $_POST['banner_height'] ) : 100 );
    $wplt->set_setting( 'banner_width',           !empty ( $_POST['banner_width'] ) ? (int) sanitize_text_field( $_POST['banner_width'] ) : 100 );
    $wplt->set_setting( 'link_url',               !empty ( $_POST['link_url'] ) ? sanitize_text_field(  $_POST['link_url'] ) : '' );
    $wplt->set_setting( 'link_text',              !empty ( $_POST['link_text'] ) ? sanitize_text_field(  $_POST['link_text'] ) : '' );
    $wplt->set_setting( 'link_title',             !empty ( $_POST['link_title'] ) ? sanitize_text_field(  $_POST['link_title'] ) : '' );
    $wplt->set_setting( 'banner_url',             !empty ( $_POST['banner_url'] ) ? esc_url_raw( $_POST['banner_url'] ) : '' );
    $wplt->set_setting( 'use_css',                sanitize_text_field( $_POST['use_css'] ) );
    $wplt->set_setting( 'secure_key',             !empty ( $_POST['secure_key'] ) ? sanitize_text_field( $_POST['secure_key'] ) : '' );
    //$wplt->set_setting( 'allow_edit',             sanitize_text_field( $_POST['allow_edit'] ) );
    $wplt->set_setting( 'use_recaptcha',    sanitize_text_field( $_POST['use_recaptcha'] ) );
    $wplt->set_setting( 'recaptcha_public_key',   !empty ( $_POST['recaptcha_public_key'] ) ? sanitize_text_field(  $_POST['recaptcha_public_key'] ) : '' );
    $wplt->set_setting( 'recaptcha_private_key',  !empty ( $_POST['recaptcha_private_key'] ) ? sanitize_text_field(  $_POST['recaptcha_private_key'] ) : '' );

    do_action( 'wplinktrade_save_settings' );

    $wplt->update_settings();

    echo '<div id="message" class="updated fade"><p>' . __("Your settings have been updated.", 'wplinktrade') . '</p></div>';
  }
 	?>
 	<div class="wrap">
    <div id="icon-options-general" class="icon32"><br /></div>
    <h2><?php _e("WPLinkExchange Settings", 'wplinktrade'); ?></h2>

    <div id="wplt_settings">

      <form method="post">
        <fieldset>

          <h3><?php _e("General Settings", 'wplinktrade'); ?></h3>

          <!-- Admin Email Notifications -->
          <div class="control-group">
            <label class="control-label" for="admin_notifications"><?php _e("Admin Email Notifications", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="admin_notifications" name="admin_notifications">
                <option value="no" <?php selected( $wplt->get_setting('admin_notifications'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('admin_notifications'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Receive email notifications on new link submissions and edit of existing links.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Partner Email Notifications -->
          <div class="control-group">
            <label class="control-label" for="partner_notifications"><?php _e("User Email Notifications", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="partner_notifications" name="partner_notifications">
                <option value="no" <?php selected( $wplt->get_setting('partner_notifications'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('partner_notifications'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Send email notification to user after link submission.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Auto Approve -->
          <div class="control-group">
            <label class="control-label" for="auto_approve"><?php _e("Auto Approve", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="auto_approve" name="auto_approve">
                <option value="no" <?php selected( $wplt->get_setting('auto_approve'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('auto_approve'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("This option will approve all submitted links automatically (not recommended)." , 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Secure Key -->
          <div class="control-group">
            <label class="control-label" for="secure_key"><?php _e("Cron Secure Key", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="secure_key" name="secure_key" value="<?php echo $wplt->get_setting('secure_key'); ?>" />
              <span class="help-block"><?php _e("Here you can change your secure key for the Backlink Cron Script.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Allow Link Editing -->
          <!-- <div class="control-group">
            <label class="control-label" for="allow_edit"><?php _e("Allow Link Editing", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="notifications" name="allow_edit">
                <option value="no" <?php //selected( $wplt->get_setting('allow_edit'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php //selected( $wplt->get_setting('allow_edit'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Allow users to edit/delete their links. If enabled a unique edit URL for each submitted link will be generated and emailed to the link partner.", 'wplinktrade'); ?></span>
            </div>
          </div> -->
          
          <!-- Description required -->
          <div class="control-group">
            <label class="control-label" for="description_required"><?php _e("Site Description Required", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="description_required" name="description_required">
                <option value="no" <?php selected( $wplt->get_setting('description_required'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('description_required'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
                <span class="help-block"><?php _e("Enable if a your link partners have to enter a short site description on the submit form.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Reciprocal Link Required -->
          <div class="control-group">
            <label class="control-label" for="reciprocal"><?php _e("Reciprocal Link Required", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="reciprocal" name="reciprocal">
                <option value="no" <?php selected( $wplt->get_setting('reciprocal'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('reciprocal'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
                <span class="help-block"><?php _e("Enable if a reciprocal link is required on users site.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Link Target -->
          <div class="control-group">
            <label class="control-label" for="link_target"><?php _e("Link Target", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="link_target" name="link_target">
                <option value="_self" <?php selected( $wplt->get_setting('link_target'), '_self' ); ?>><?php _e('Same Window', 'wplinktrade'); ?></option>
                <option value="_blank" <?php selected( $wplt->get_setting('link_target'), '_blank' ); ?>><?php _e('New Window', 'wplinktrade'); ?></option>
              </select>
                <span class="help-block"><?php _e("Set if the link should should be opened in a new widow.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Link Relation -->
          <div class="control-group">
            <label class="control-label" for="relation"><?php _e("Link Relation", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="relation" name="relation">
                <option value="none" <?php selected( $wplt->get_setting('relation'), 'none' ); ?>><?php _e('None', 'wplinktrade'); ?></option>
                <option value="bookmark" <?php selected( $wplt->get_setting('relation'), 'bookmark' ); ?>><?php _e('Bookmark', 'wplinktrade'); ?></option>
                <option value="nofollow" <?php selected( $wplt->get_setting('relation'), 'nofollow' ); ?>><?php _e('No Follow', 'wplinktrade'); ?></option>
              </select>
                <span class="help-block"><?php _e("Set the link relation attribute 'rel=...'.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Link Exchange Types -->
          <?php
          $exchange_type = $wplt->get_setting('exchange_type');
          ?>
          <div class="control-group">
            <label class="control-label" for="exchange_type"><?php _e("Link Exchange Types", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="checkbox" name="exchange_type[text]" value="yes" <?php echo checked( $exchange_type['text'], 'yes') ?>> <?php _e('Text Link Exchange', 'wplinktrade'); ?><br />
              <input type="checkbox" name="exchange_type[image]" value="yes" <?php echo checked( $exchange_type['image'], 'yes') ?>> <?php _e('Banner Exchange', 'wplinktrade'); ?>
              <span class="help-block"><?php _e("Set link exchange types you want to allow on your site.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <!-- Categorize Links -->
          <div class="control-group">
            <label class="control-label" for="categorize"><?php _e("Categorize Link Partners", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="categorize" name="categorize">
                <option value="no" <?php selected( $wplt->get_setting('categorize'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('categorize'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Categorize Link Partners. Therefor you will need to create some WPLinkTrade categories.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <h4><?php _e("reCAPTCHA Settings", 'wplinktrade'); ?></h4>
          <p><?php _e("Enabling reCAPTCHA will help you fighting Spam submissions. To use reCAPTCHA you must get an API key from <a href='https://www.google.com/recaptcha/admin/create'>https://www.google.com/recaptcha/admin/create</a>", 'wplinktrade'); ?></p>

          <div class="control-group">
            <label class="control-label" for="enable_recaptcha"><?php _e("Enable reCAPTCHA", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="use_recaptcha" name="use_recaptcha">
                <option value="no" <?php selected( $wplt->get_setting('use_recaptcha'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('use_recaptcha'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Display reCAPTCHA on the subbmit form.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="recaptcha_public_key"><?php _e("reCAPTCHA public key", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="recaptcha_public_key" name="recaptcha_public_key" value="<?php echo $wplt->get_setting('recaptcha_public_key'); ?>" />
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="recaptcha_private_key"><?php _e("reCAPTCHA private key", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="recaptcha_private_key" name="recaptcha_private_key" value="<?php echo $wplt->get_setting('recaptcha_private_key'); ?>" />
            </div>
          </div>

          <?php do_action( 'wplinktrade_fields_general_settings' ); ?>

          <h4><?php _e("Banner Image Dimension", 'wplinktrade'); ?></h4>

          <p><?php _e('If banner exchange is enabled then you should define the banner size (in pixels).', 'wplinktrade'); ?></p>

          <div class="control-group">
            <label class="control-label" for="banner_width"><?php _e("Width", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="banner_width" name="banner_width" value="<?php echo $wplt->get_setting('banner_width'); ?>" />
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="banner_height"><?php _e("Height", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="banner_height" name="banner_height" value="<?php echo $wplt->get_setting('banner_height'); ?>" />
            </div>
          </div>

          <h3><?php _e("Theme Integration", 'wplinktrade'); ?></h3>

          <!-- Use WPLinkTrade CSS -->
          <div class="control-group">
            <label class="control-label" for="use_css"><?php _e("WPLinkTrade CSS Style", 'wplinktrade'); ?></label>
            <div class="controls">
              <select id="use_css" name="use_css">
                <option value="no" <?php selected( $wplt->get_setting('use_css'), 'no' ); ?>><?php _e('No', 'wplinktrade'); ?></option>
                <option value="yes" <?php selected( $wplt->get_setting('use_css'), 'yes' ); ?>><?php _e('Yes', 'wplinktrade'); ?></option>
              </select>
              <span class="help-block"><?php _e("Use the WPLinkTrade default CSS styles for stats and forms.", 'wplinktrade'); ?></span>
            </div>
          </div>

          <h3><?php _e("Your Link Settings", 'wplinktrade'); ?></h3>

          <div class="controls">
            <pre>&lt;a href="#" title="<strong><?php _e("Link Title", 'wplinktrade'); ?></strong>"&gt;<strong><?php _e("Link Text", 'wplinktrade'); ?></strong>&lt;/a&gt;</pre>
          </div>

          <div class="control-group">
            <label class="control-label" for="link_url"><?php _e("Link URL", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="link_url" name="link_url" value="<?php echo $wplt->get_setting('link_url'); ?>" />
              <span class="help-block"><?php _e('Set the link URL for your site.', 'wplinktrade'); ?></span>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="link_text"><?php _e("Link Text", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="link_text" name="link_text" value="<?php echo $wplt->get_setting('link_text'); ?>" />
              <span class="help-block"><?php _e('Set the link text for your site.', 'wplinktrade'); ?></span>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="link_title"><?php _e("Link Title", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="link_title" name="link_title" value="<?php echo $wplt->get_setting('link_title'); ?>" />
              <span class="help-block"><?php _e('Set the link title for your site.', 'wplinktrade'); ?></span>
            </div>
          </div>

          <div class="control-group">
            <label class="control-label" for="banner_url"><?php _e("Banner Image URL", 'wplinktrade'); ?></label>
            <div class="controls">
              <input type="text" id="banner_url" name="banner_url" value="<?php echo $wplt->get_setting('banner_url'); ?>" />
              <span class="help-block"><?php _e('Add your banner URL if you are using banner exchange.', 'wplinktrade'); ?></span>
            </div>
          </div>

          <?php do_action( 'wplinktrade_fields_settings_bottom' ); ?>

          <h3><?php _e("Cron - Backlick Check", 'wplinktrade'); ?></h3>

          <p><?php _e("WPLinkTrade is able to check if your partner sites still have backlinks to your page. Therefor you will need to setup a cron job that is executed weekly or daily.", 'wplinktrade'); ?></p>
          <p><?php _e("This is your URL which should be triggered by cron:", 'wplinktrade'); ?></p>
          <pre><?php echo $wplt->plugin_url . 'cron.php?secret=' . $wplt->get_setting('secure_key'); ?></pre>
        </fieldset>

        <input type="submit" name="wplt_save_settings" class="button-primary" value="<?php _e("Save settings", 'wplinktrade'); ?>" />
      </form>


      <div class="clear"></div>
    </div><!-- /end wplt-settings -->
 	</div>
 	<?php
}