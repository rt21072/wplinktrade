<?php
/**
 * WPLinkTrade Uninstall
 */

if( !defined('WP_UNINSTALL_PLUGIN') ) exit();

global $wpdb;

if ( wp_next_scheduled( 'wplinktrade_midnight_event' ) ) {
  wp_clear_scheduled_hook( 'wplinktrade_midnight_event' );
}

// Delete all WPLinkTrade options
$wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE 'wplinktrade%';");