<?php
/**
 * Front End Functions
 */

/**
 * Generates a link for the queried link partner.
 */
if ( ! function_exists( 'wplinktrade_get_link' ) )
{
  function wplinktrade_get_link() {
    global $post, $wplt;

    if ( empty( $post->ID ) ) return false;

    // Init needed vars
    $relation   = '';
    $title      = '';

    // Get link details
    $url        = get_post_meta( $post->ID, 'site_url', true );
    $text       = get_the_title();
    $raw_title  = get_post_meta( $post->ID, 'link_title', true );
    $target     = ' target="' . $wplt->get_setting( 'link_target' ) . '"';

    if ( $raw_title ) $title = ' title="'.$raw_title.'"';
    if ( $wplt->get_setting( 'relation' ) != 'none' ) $relation = ' rel="' . $wplt->get_setting( 'relation' ) . '"';

    return '<a href="'. $url .'"'. $title . $target . $relation .'>'. $text .'</a>';
  }
}

/**
 * Generates the banner link
 */
if ( ! function_exists( 'wplinktrade_get_banner' ) )
{
  function wplinktrade_get_banner( $width = 100, $height = 100) {
    global $post, $wplt;

    if ( empty( $post->ID ) ) return false;

    // Init needed vars
    $relation   = '';
    $title      = '';

    // Get link details
    $url        = get_post_meta( $post->ID, 'site_url', true );
    $text       = get_the_title();
    $raw_title  = get_post_meta( $post->ID, 'link_title', true );
    $target     = ' target="' . $wplt->get_setting( 'link_target' ) . '"';
    $banner     = wp_get_attachment_url( get_post_thumbnail_id( $post->ID ) );

    if ( $raw_title ) $title = ' title="'.$raw_title.'"';
    if ( $wplt->get_setting( 'relation' ) != 'none' ) $relation = ' rel="' . $wplt->get_setting( 'relation' ) . '"';

    if ( $banner ) {
      return '<a href="'. $url .'"'. $title . $target . $relation .'>
        <img src="'. $banner .'" alt="'. $raw_title .'" width="'. $width .'" height="'. $height .'" />
      </a>';
    }

    // No Banner found!!!
    return false;
  }
}

if( !function_exists('wplinktrade_get_description') )
{
  function wplinktrade_get_description() {
    global $post, $wplt;

    if ( empty( $post->ID ) ) return false;
    
    return htmlspecialchars_decode( get_post_meta( $post->ID, 'site_description', true ) );
  }
}