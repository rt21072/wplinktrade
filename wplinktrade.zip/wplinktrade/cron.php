<?php
/**
 * WPLinkTrade Backlink Checker Cron
 *
 * Call this file within a cron job.
 * On each call this script will check if your backlink is
 * still online on partner sites and you will get an email report
 * if admin notifications are enabled on WPLinktrade Settings.
 *
 * We recommend to run the cron job daily or weekly.
 *
 * @author    Daniel Bakovic
 * @category  Cron
 * @package   WPLinkTrade/Cron
 */

// Ceck if the file has been called with a secret key..
if ( ! isset( $_GET['secret'] ) ) {
  exit();
}

// Load WordPress
$wp_root = dirname( dirname( dirname( dirname( __FILE__ ) ) ) );

if ( ! file_exists( $wp_root . '/wp-load.php' ) ) {
  exit();
}

require_once( $wp_root . '/wp-load.php' );

// Check if WPLinkTrade is activated
global $wplt;

if ( ! is_object( $wplt ) ) {
  exit();
}

// Check secet key
if ( $wplt->get_setting( 'secure_key' ) != $_GET['secret'] ) {
  exit();
}

$partners = $wplt->check_all_backlinks();

// Send report email if activated
if ( !empty( $partners ) && $wplt->get_setting( 'admin_notifications' ) == 'yes' ) {
  $wplt->send_report( $partners );
}

exit();