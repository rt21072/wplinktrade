<?php
/**
 * Link List Start
 */
?>
<div class="wplinktrade_stats wplinktrade_links">
  <table class="stats_table" callspacing="1">
    <thead>
      <tr>
        <th><?php _e("Site", 'wplinktrade'); ?></th>
        <th><?php _e("Today In", 'wplinktrade'); ?></th>
        <th><?php _e("Today Out", 'wplinktrade'); ?></th>
        <th><?php _e("Total In", 'wplinktrade'); ?></th>
        <th><?php _e("Total Out", 'wplinktrade'); ?></th>
        <th><?php _e("Ratio", 'wplinktrade'); ?></th>
      </tr>
    </thead>
    <tbody>