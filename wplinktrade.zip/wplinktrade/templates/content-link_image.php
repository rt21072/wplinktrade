<?php
/**
 * The tempalte for displaying banner link content within loops
 *
 * Override this template by copying it to yourtheme/wplinktrade/content-link_image.php
 */

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly
?>
<tr>
  <td>
    <?php echo wplinktrade_get_link(); ?><br />
    <?php echo wplinktrade_get_banner(); ?>
  </td>
  <td><?php echo (int) get_post_meta( $post->ID, 'today_in', true ); ?></td>
  <td><?php echo (int) get_post_meta( $post->ID, 'today_out', true ); ?></td>
  <td><?php echo (int) get_post_meta( $post->ID, 'total_in', true ); ?></td>
  <td><?php echo (int) get_post_meta( $post->ID, 'total_out', true ); ?></td>
  <td><?php echo floatval(get_post_meta( $post->ID, 'ratio', true )); ?>%</td>
</tr>