<?php
/**
 * The template for displaying the first step on link submissions
 */

// Hide if a link has been submitted
if ( ! filter_input( INPUT_POST, 'link_submission' ) ) :

global $wplt;
$exchange_type  = $wplt->get_setting('exchange_type');
$banner_url     = $wplt->get_setting('banner_url');
?>
<h4><?php _e("Add our link to your website.", 'wplinktrade'); ?></h4>

<div class="wplinktrade_alert wplinktrade_info">
  <?php _e("Before you submit your link you will need to add our link to your site. Otherwise your submission will be declined automatically.", 'wplinktrade'); ?>
</div>

<h5><?php _e("Link Details", 'wplinktrade'); ?></h5>

<table class="wplinktrade_step_1_table" width="100%">
  <tr>
    <td style="width:50%"><?php _e("Website URL", 'wplinktrade'); ?></td>
    <td><?php echo $wplt->get_setting('link_url'); ?></td>
  </tr>
  <tr>
    <td style="width:50%"><?php _e("Website Text", 'wplinktrade'); ?></td>
    <td><?php echo $wplt->get_setting('link_text'); ?></td>
  </tr>
  <tr>
    <td style="width:50%"><?php _e("Website Title", 'wplinktrade'); ?></td>
    <td><?php echo $wplt->get_setting('link_title'); ?></td>
  </tr>
  <?php if ( $exchange_type['image'] == 'yes' && $banner_url ) : ?>
  <tr>
    <td style="width:50%"><?php _e("Banner URL", 'wplinktrade'); ?></td>
    <td><?php echo $banner_url; ?></td>
  </tr>
  <?php endif; ?>
</table>

<h5><?php _e("Link Code", 'wplinktrade'); ?></h5>
<p><?php _e("Here is the complete link code how it should look on your site:", 'wplinktrade'); ?></p>

<?php if ( $exchange_type['text'] == 'yes' ) : ?>
<h6><?php _e("Text Link", 'wplinktrade'); ?></h6>
<pre>&lt;a href="<?php echo $wplt->get_setting('link_url') ?>" title="<?php echo $wplt->get_setting('link_title') ?>" target="<?php echo $wplt->get_setting('link_target') ?>"&gt;<?php echo $wplt->get_setting('link_text') ?>&lt;/a&gt;</pre>
<p>
  <a href="<?php echo $wplt->get_setting('link_url') ?>" title="<?php echo $wplt->get_setting('link_title') ?>" target="<?php echo $wplt->get_setting('link_target') ?>"><?php echo $wplt->get_setting('link_text') ?></a>
</p>
<?php endif; ?>

<?php if ( $exchange_type['image'] == 'yes' && $banner_url ) : ?>
<h6><?php _e("Banner Link", 'wplinktrade'); ?></h6>
<pre>&lt;a href="<?php echo $wplt->get_setting('link_url') ?>" title="<?php echo $wplt->get_setting('link_title') ?>" target="<?php echo $wplt->get_setting('link_target') ?>"&gt;&lt;img src="<?php echo $banner_url; ?>" alt="<?php echo $wplt->get_setting('link_title'); ?>" /&gt;&lt;/a&gt;</pre>
<p>
  <a href="<?php echo $wplt->get_setting('link_url') ?>" title="<?php echo $wplt->get_setting('link_title') ?>" target="<?php echo $wplt->get_setting('link_target') ?>"><img src="<?php echo $banner_url; ?>" alt="<?php echo $wplt->get_setting('link_title'); ?>" /></a>
</p>
<?php endif; ?>
<?php endif; ?>
