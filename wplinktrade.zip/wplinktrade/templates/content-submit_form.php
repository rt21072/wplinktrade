<?php
/**
 * The template for displaying the link submission form
 */
global $wplt;

// Populate the form_data array with default / submitted or edit link data.
$form_data = $wplt->get_form_data();

// Display messages if there are some
if ( $wplt->have_messages() ) {
  foreach( $wplt->get_messages() as $message ) {
    ?>
    <div class="wplinktrade_alert wplinktrade_<?php echo $message['type']; ?>">
      <?php echo $message['message']; ?>
    </div>
    <?php
  }
}
?>

<h5><?php _e("Your site details", 'wplinktrade'); ?></h5>

<pre>&lt;a href="<strong>SITE URL</strong>" title="<strong>LINK TITLE</strong>"&gt;<strong>SITE NAME</strong>&lt;/a&gt;</pre>

<form name="linkpartner_form" id="linkpartner_form" method="post" enctype="multipart/form-data">

  <?php do_action( 'wplinktrade_submit_form_top' ); ?>

  <div class="control-group">
    <label class="control-label" for="site_url"><?php _e("Site URL", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" id="site_url" name="site_url" value="<?php echo $form_data['site_url']; ?>" />
      <div class="help-block"><?php _e("Enter your URL.", 'wplinktrade'); ?></div>
    </div>
  </div>

  <div class="control-group">
    <label class="control-label" for="site_name"><?php _e("Site Name", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" id="site_name" name="site_name" value="<?php echo $form_data['site_name']; ?>" />
      <div class="help-block"><?php _e("Enter the name of your site.", 'wplinktrade'); ?></div>
    </div>
  </div>
  
  <?php if ( $wplt->get_setting( 'description_required' ) == 'yes'  ): ?>
  <div class="control-group">
    <label class="control-label" for="site_description"><?php _e("Site Description", 'wplinktrade'); ?></label>
    <div class="controls">
      <textarea id="site_description" name="site_description"><?php echo $form_data['site_description']; ?></textarea>
      <div class="help-block"><?php _e("Enter a short description of your site.", 'wplinktrade'); ?></div>
    </div>
  </div>
  <?php endif; ?>

  <div class="control-group">
    <label class="control-label" for="link_title"><?php _e("Link Title", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" id="link_title" name="link_title" value="<?php echo $form_data['link_title']; ?>" />
      <div class="help-block"><?php _e("Enter the link title for your site.", 'wplinktrade'); ?></div>
    </div>
  </div>

  <?php if ( 'yes' == $wplt->get_setting( 'categorize' ) ) : ?>
    <?php
    $wplt_terms = get_terms( array( 'linktrade_cat' ), array( 'hide_empty' => false ) );
    if ( $wplt_terms ) : ?>
    <div class="control-group">
      <label class="control-label" for="link_category"><?php _e("Link Category", 'wplinktrade'); ?></label>
      <div class="controls">
        <select name="link_category" id="link_category">
          <option value="0"><?php _e("Select a category...", 'wplinktrade'); ?></option>
          <?php foreach ( $wplt_terms as $term ) {
            echo '<option value="'.$term->term_id.'" '.selected( $form_data['link_category'], $term->term_id ).'>'.$term->name.'</option>';
          }
          ?>
        </select>
        <div class="help-block"><?php _e("Select a link category.", 'wplinktrade'); ?></div>
      </div>
    </div>
    <?php endif; ?>
  <?php endif; ?>

  <?php
  $exchange_type = $wplt->get_setting( 'exchange_type' );

  if ( $exchange_type['text'] == 'yes' && $exchange_type['image'] == 'yes' ) :
    ?>
    <div class="control-group">
      <label class="control-label" for="link_type"><?php _e("Exchange Type", 'wplinktrade'); ?></label>
      <div class="controls">
        <select id="link_type" name="link_type">
          <option value="text" <?php selected( $form_data['link_type'], 'text') ?>><?php _e('Text', 'wplinktrade'); ?></option>
          <option value="image" <?php selected( $form_data['link_type'], 'image') ?>><?php _e('Image', 'wplinktrade'); ?></option>
        </select>
        <div class="help-block"><?php _e("Select the exchange type.", 'wplinktrade'); ?></div>
      </div>
    </div>
    <?php
  endif;

  if ( $exchange_type['image'] == 'yes' ) :
    ?>
    <div class="control-group" id="banner_upload">
      <label class="control-label" for="banner_file"><?php _e("Banner File", 'wplinktrade'); ?></label>
      <div class="controls">
        <input type="file" name="banner_file" id="banner_file" />
        <div class="help-block"><?php echo sprintf( __("Upload a %sx%spx banner.", 'wplinktrade'), $wplt->get_setting('banner_width'), $wplt->get_setting('banner_height') ); ?></div>
      </div>
    </div>
    <?php
  endif;
  ?>

  <div class="control-group">
    <label class="control-label" for="reciprocal_link"><?php _e("Backlink Location", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" name="reciprocal_link" id="reciprocal_link" value="<?php echo $form_data['reciprocal_link']; ?>" />
      <div class="help-block"><?php _e("Enter the URL where you have embeded our link.", 'wplinktrade'); ?></div>
    </div>
  </div>

   <div class="control-group">
    <label class="control-label" for="contact_name"><?php _e("Your Name", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" name="contact_name" id="contact_name" value="<?php echo $form_data['contact_name']; ?>" />
      <div class="help-block"><?php _e("Enter your name.", 'wplinktrade'); ?></div>
    </div>
  </div>

   <div class="control-group">
    <label class="control-label" for="contact_email"><?php _e("Your E-Mail", 'wplinktrade'); ?></label>
    <div class="controls">
      <input type="text" name="contact_email" id="contact_email" value="<?php echo $form_data['contact_email']; ?>" />
      <div class="help-block"><?php _e("Enter your email address.", 'wplinktrade'); ?></div>
    </div>
  </div>

  <?php do_action( 'wplinktrade_submit_form_bottom' ); ?>

  <?php if ( $wplt->get_setting( 'use_recaptcha' ) == 'yes' ) : ?>
  <?php if ( ! function_exists( 'recaptcha_get_html' ) ) require_once( $wplt->plugin_dir ."lib/recaptchalib.php" ); ?>
  <div class="control-group">
    <div class="controls">
      <?php echo recaptcha_get_html( $wplt->get_setting('recaptcha_public_key') ); ?>
    </div>
  </div>
  <?php endif; ?>

  <div class="control-group">
    <div class="controls">
      <input type="submit" class="btn btn-primary" name="link_submission" value="<?php _e("Submit Link", 'wplinktrade'); ?>" />
    </div>
  </div>
</form>