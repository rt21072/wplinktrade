jQuery(document).ready( function($) {
  // Count outgoing clicks
  $(".wplinktrade_links a").click(function () {
    $.ajax( {
      type: 'POST',
      url: wpajaxurl,
      data: {
        action: "wplinktrade_outgoing_click",
        link: $(this).attr("href")
      }
    });
    return true;
  });

  // Banner upload form
  $('#link_type').change( function() {
    if( $(this).val() == "image" ) {
      $('#banner_upload').show();
    }
    else {
      $('#banner_upload').hide();
    }
  });

  // If text and banner exchange types are activated
  // then hide banner upload first.
  if ( $("#link_type").length > 0 ) {
    $('#banner_upload').hide();
  }

  if ( $('#link_type').val() == "image" ) {
    $('#banner_upload').show();
  }
});