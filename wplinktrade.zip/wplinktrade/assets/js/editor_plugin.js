(function() {
var icon_url = '../wp-content/plugins/wplinktrade/assets/images/wplt.png';
tinymce.PluginManager.add('wplts', function( editor, url ) {
  editor.addButton( 'wplts', {
    title: 'WPLinkTrade Shortcodes',
    type: 'menubutton',
    icon: 'icon wplts-icon',
    menu: [
      { text: 'Text Link Stats', value: '[wplinktrade_stats type="text" orderby="total_in" order="DESC"]', onclick: function() { editor.insertContent(this.value()); } },
      { text: 'Text Link List', value: '[wplinktrade_list type="text" orderby="total_in" order="DESC"]', onclick: function() { editor.insertContent(this.value()); } },
      { text: 'Banner Link Stats', value: '[wplinktrade_stats type="image" orderby="total_in" order="DESC"]', onclick: function() { editor.insertContent(this.value()); } },
      { text: 'Banner Link List', value: '[wplinktrade_list type="image" orderby="total_in" order="DESC"]', onclick: function() { editor.insertContent(this.value()); } },
      { text: 'Submit Form Step 1', value: '[wplinktrade_submit_step_1]', onclick: function() { editor.insertContent(this.value()); } },
      { text: 'Submit Form', value: '[wplinktrade_submit]', onclick: function() { editor.insertContent(this.value()); } }
    ]
  });
});
})();