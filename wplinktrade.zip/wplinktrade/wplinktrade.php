<?php
/**
 * Plugin Name:  WPLinkTrade
 * Plugin URI:   https://ezhostor.com
 * Description:  Offer link and banner exchange on your site
 * Version:      1.6.2
 * Author:       EzHostor
 * Author URI:   https://ezhostor.com
 * License:      GPLv2 or later
 * License URI:  http://www.gnu.org/licenses/gpl-2.0.html
 *
 * Requires at least: 4.0
 * Tested up to: 4.5
 *
 * Text Domain:  wplinktrade
 * Domain Path:  /languages/
 *
 * @package WPLinkTrade
 * @category Core
 * @author Ezhostor
 *
 * Copyright 2020-202024 Ezhostor (email: support@ezhostor.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

// No direct access!
if ( !defined('ABSPATH') ) exit;

if ( !class_exists( 'WPLinkTrade') ) {

class WPLinkTrade {

  /** @var string Plugin version number */
  var $version = '1.6.1';

  // Plugin paths and urls
  var $file;
  var $basename;
  var $plugin_dir;
  var $plugin_url;
  var $template_url;
  var $lang_dir;

  /** @var array Stores global plugin settings */
  var $settings = array();

  /** @mixed Shortcode object placeholder */
  var $shortcodes;

  /** @array Holds all messages */
  var $messages = array();

  /** @var int The Post ID of the current linktrade post (linkpartner) */
  var $post_id;

  /** @var array Holds data of the current link partner */
  var $partner = array();

  /** @var WPLinkTrade_Emails */
  var $email;


  /**
   * WPLinkTrade Constructor
   *
   * @access public
   * @return void
   */
  public function __construct() {

    // Define version constant
    define( 'WPLINKTRADE_VERSION', $this->version );

    // Setup globla variables
    $this->setup_globals();

    // Include required files
    $this->includes();

    // Auto load classes on demand
    spl_autoload_register( array( $this, 'autoload') );

    // Installation, Update, Uninstall ...
    register_activation_hook( $this->file, array( $this, 'activate' ) );
    register_deactivation_hook( $this->file, array( $this, 'deactivate' ) );
    add_action( 'admin_init', array( $this, 'install' ), 5 );

    // Actions
    add_action( 'init', array( $this, 'init' ), 0 );
    add_action( 'wplinktrade_midnight_event', array( $this, 'midnight_event' ) );
    add_action( 'wp_head', array( $this, 'frontend_scripts' ) );
    add_action( 'widgets_init', array( $this, 'register_widgets' ) );
    add_action( 'after_setup_theme', array( $this, 'theme_setup') );

    // AJAX callbacks to be able to count links
    add_action( 'wp_ajax_nopriv_wplinktrade_outgoing_click', array( $this, 'outgoing') );
    add_action( 'wp_ajax_wplinktrade_outgoing_click', array( $this, 'outgoing') );

    add_filter( 'upload_dir', array( $this, 'upload_dir' ) );
    add_filter( 'intermediate_image_sizes', array( $this, 'remove_default_image_sizes' ) );
    add_filter( 'wp_generate_attachment_metadata', array( $this, 'replace_uploaded_image') );

    // Loaded action
    do_action( 'wplinktrade_loaded' );
  }

  /**
   * Setup global class variables
   *
   * @access private
   * @return void
   */
  private function setup_globals() {

    // Paths - plugin
    $this->file         = __FILE__;
    $this->basename     = plugin_basename( $this->file );
    $this->plugin_dir   = plugin_dir_path( $this->file );
    $this->plugin_url   = plugin_dir_url ( $this->file );
    $this->template_url = apply_filters( 'wplinktrade_template_url', 'wplinktrade/' );
    $this->lang_dir     = trailingslashit( $this->plugin_dir . 'languages' );

    // Init settings
    $this->get_settings();
  }

  /**
   * Include required files
   *
   * @access private
   * @return void
   */
  private function includes() {
    global $pagenow;

    // Admin Includes
    if ( is_admin() ) {
      require_once( $this->plugin_dir . 'admin/admin.php' );

      if ( $pagenow == 'post-new.php' || $pagenow == 'post.php' || $pagenow == 'edit.php' ) {
        include_once ( $this->plugin_dir . 'admin/writepanels.php' );
      }
    }

    // Frontend Includes
    if ( ! is_admin() ) {
      include_once ( $this->plugin_dir . 'wplinktrade-frontend-functions.php' );
      include_once ( $this->plugin_dir . 'wplinktrade-template.php' );
    }
  }

  /**
   * Auto load WPLinkTrade classes on demand to reduce memory consum consumption.
   *
   * @access public
   * @param mixed $class
   * @return void
   */
  public function autoload( $class ) {

    $class = strtolower( $class );

    if ( strpos( $class, 'wplinktrade_' ) === 0 ) {

      $path = $this->plugin_dir . '/classes/';
      $file = 'class-' . str_replace( '_', '-', $class ) . '.php';

      if ( is_readable( $path . $file ) ) {
        include_once( $path . $file );
        return;
      }
    }
  }

  /**
   * Load fronend scripts
   *
   * @access public
   * @return void
   */
  public function frontend_scripts() {
    if ( !is_admin() ) {
      echo '<script type="text/javascript">var wpajaxurl = "'.admin_url( 'admin-ajax.php' ).'";</script>';
      wp_enqueue_script( 'wplinktrade', $this->plugin_url . 'assets/js/wplinktrade.js', array( 'jquery' ) );

      if ( $this->get_setting( 'use_css') == 'yes' ) {
        wp_enqueue_style( 'wplinktrade_frontend_css', $this->plugin_url . 'assets/css/wplt_frontend.css' );
      }
    }
  }

  /**
   * Init WPLinkTrade when WordPress initializes
   *
   * @access public
   * @return void
   */
  public function init() {

    // Class instances
    $this->shortcodes = new WPLinkTrade_Shortcodes();

    // Check for the scheduled event
    $this->schedule_midnight_event();

    // Check for inlinks
    $this->incoming();

    // Set up localization
    $this->load_plugin_textdomain();

    // Init WPLinkTrade taxonomies
    $this->init_taxonomy();

    // Init Image sizes
    $this->init_image_sizes();

    // Proceed submissions
    $this->proceed_submission();

    // Check if this is a back link check request
    $backlink_check = filter_input( INPUT_POST, 'wplinktrade_link_check');
    $nonce_field = filter_input( INPUT_POST, 'wplinktrade_link_check_nonce_field' );
    if ( is_admin() && $backlink_check && $nonce_field ) {
      if ( wp_verify_nonce( $nonce_field, 'wplinktrade_link_check_nonce_action' ) ) {
        $this->check_all_backlinks();
      }
    }

    // Init action
    do_action( 'wplinktrade_init' );
  }

  /**
   * Load Localization files.
   *
   * @access public
   * @return void
   */
  public function load_plugin_textdomain() {
    load_plugin_textdomain( 'wplinktrade', false, dirname( plugin_basename( __FILE__ ) ) . "/languages" );
  }

  /**
   * Get form data
   *
   * @access public
   * @return public
   */
  public function get_form_data() {
    $form_data                     = array();
    $form_data['site_url']         = !empty( $_POST['site_url'] ) ? esc_url_raw( $_POST['site_url'] ) : '';
    $form_data['site_name']        = !empty( $_POST['site_name'] ) ? sanitize_text_field( $_POST['site_name'] ) : '';
    $form_data['site_description'] = !empty( $_POST['site_description']) ? esc_textarea( $_POST['site_description']) : '';
    $form_data['link_title']       = !empty( $_POST['link_title'] ) ? sanitize_text_field( $_POST['link_title'] ) : '';
    $form_data['link_category']    = !empty( $_POST['link_category'] ) ? sanitize_text_field( $_POST['link_category'] ) : '';
    $form_data['link_type']        = !empty( $_POST['link_type'] ) ? sanitize_text_field( $_POST['link_type'] ) : false;
    $form_data['reciprocal_link']  = !empty( $_POST['reciprocal_link'] ) ? esc_url_raw( $_POST['reciprocal_link'] ) : '';
    $form_data['contact_name']     = !empty( $_POST['contact_name'] ) ? sanitize_text_field( $_POST['contact_name'] ) : '';
    $form_data['contact_email']    = !empty( $_POST['contact_email'] ) ? sanitize_email( $_POST['contact_email'] ) : '';

    return apply_filters( 'wplinktrade_form_data', $form_data );
  }

  /**
   * Proceed link submissions
   *
   * @access  private
   * @version 1.5.0
   * @since   1.0.0
   * @return  void
   */
  private function proceed_submission() {

    if ( empty( $_POST ) || empty( $_POST['link_submission'] ) ) {
      return;
    }

    $exchange_type = $this->get_setting( 'exchange_type' );

    if ( empty( $_POST['link_type'] ) ) {
      if ( $exchange_type['text'] == 'yes' && $exchange_type['image'] != 'yes' ) {
        $this->set_detail( 'link_type', 'text' );
      }
      else {
        $this->set_detail( 'link_type', 'image' );
      }
    }
    else {
      $this->set_detail('link_type', ! empty( $_POST['link_type'] ) ? sanitize_text_field( $_POST['link_type'] ) : false );
    }

    // Check submitted fields
    $this->set_detail('site_url',         ! empty( $_POST['site_url'] ) ? esc_url_raw( $_POST['site_url'] ) : false );
    $this->set_detail('site_name',        ! empty( $_POST['site_name'] ) ? sanitize_text_field( $_POST['site_name'] ) : false );
    $this->set_detail('link_title',       ! empty( $_POST['link_title'] ) ? sanitize_text_field( $_POST['link_title'] ) : false );

    if ( 'yes' == $this->get_setting( 'categorize' ) && get_terms( array( 'linktrade_cat' ), array( 'hide_empty' => false ) ) ) {
      $this->set_detail('link_category', ! empty( $_POST['link_category'] ) ? intval( $_POST['link_category'] ) : false );
    }

    if ( $this->get_setting('description_required') == 'yes' ) {
      $this->set_detail('site_description', ! empty( $_POST['site_description'] ) ? esc_textarea( $_POST['site_description'] ) : false );
    }

    // Add the global setting for reciprocal links to the partner
    $this->set_detail('reciprocal_link_required', $this->get_setting( 'reciprocal' ) );
    if ( $this->get_setting( 'reciprocal' ) == 'yes' ) {
      $this->set_detail('reciprocal_link',  ! empty( $_POST['reciprocal_link'] ) ? esc_url_raw( $_POST['reciprocal_link'] ) : false );
    }

    $this->set_detail('contact_name',     ! empty( $_POST['contact_name'] ) ? sanitize_text_field( $_POST['contact_name'] ) : false );
    $this->set_detail('contact_email',    ! empty( $_POST['contact_email'] ) ? sanitize_email( $_POST['contact_email'] ) : false );

    do_action( 'wplinktrade_proceed_submission_required_fields' );

    // Check if all needed fields have been filled out
    foreach ( $this->get_details() as $key => $val ) {
      if ( ! $val ) {
        $this->add_error(
          apply_filters( 'wplinktrade_submit_form_fields_error', __("Not all required fields have been entered!", 'wplinktrade') )
        );

        // Abort
        return;
      }
    }

    do_action( 'wplinktrade_proceed_submission_optional_fields' );

    // Check reCAPTCHA
    if ( $this->get_setting( 'use_recaptcha' ) == 'yes' ) {
      if ( ! function_exists( "recaptcha_get_html" ) ) {
        require_once( $this->plugin_dir ."lib/recaptchalib.php" );
      }
      if ( ! empty( $_POST["recaptcha_challenge_field"] ) && ! empty( $_POST["recaptcha_response_field"] ) ) {
        $response = recaptcha_check_answer( $this->get_setting('recaptcha_private_key'), $_SERVER["REMOTE_ADDR"], $_POST["recaptcha_challenge_field"], $_POST["recaptcha_response_field"] );
        if ( ! $response->is_valid ) {
          $this->add_error(
            apply_filters( 'wplinktrade_submit_form_recaptcha_wrong', __("Anti-Spam check was wrong!", 'wplinktrade') )
          );

          // Abort
          return;
        }
      }
      else {
        $this->add_error(
          apply_filters( 'wplinktrade_submit_form_recaptcha_error', __("Anti-Spam check is empty!", 'wplinktrade') )
        );

        // Abort
        return;
      }
    }

    // Check if this Linkparter already exists
    if ( $this->partner_exists( ) ) {
      $this->add_error(
        apply_filters( 'wplinktrade_submit_form_partner_exists', __("Sorry, but a partner with the same URL already exists!", 'wplinktrade') )
      );

      // Abort
      return;
    }

    // Check reciprocal link if required
    if ( $this->get_detail('reciprocal_link_required') == 'yes' ) {
      $check = $this->check_backlink();

      if ( $check === -1 ) {
        return false; /* Verification ERROR! Site can't be fetched or system error! */
      }

      if ( $check ) {
        $this->set_detail( 'backlink', true );
      }
      else {
        $this->add_error(
          apply_filters( 'wplinktrade_submit_form_backlink_missing', __("Sorry, but the backlink to our site can't be found. Please add our link at your site before you submit your link!", 'wplinktrade')
          )
        );

        // Abort
        return;
      }
    }
    else {
      // Backlink not required and not checked, yet
      $this->set_detail( 'backlink', false );
    }

    //Banner image?
    $this->set_detail( 'exchange_type', 'text' );

    if ( ($exchange_type['image'] == 'yes') && isset( $_FILES['banner_file'] ) ) {
      if ( isset( $_POST['link_type'] ) && $_POST['link_type'] == 'image' ) {
        $filetype = wp_check_filetype( $_FILES['banner_file']['name'] );
        if ( stristr($filetype['type'], 'image') === FALSE ) {
          $this->add_error(
            apply_filters( 'wplinktrade_submit_form_filetype_not_allowed', __("Please upload only image file types (png or jpg)!", 'wplinktrade') )
          );
          // Abort
          return;
        }

        $this->set_detail( 'exchange_type', 'image' );
      }
    }

    // If we are here then everything seems to be ok.
    // Insert link partner
    if ( $this->insert_partner() ) {

      // Send mails
      $this->send_notifications();

      $this->add_info(
        apply_filters( 'wplinktrade_link_submitted', __("Thank you! Your link has been submitted!", 'wplinktrade') )
      );
    }
    else {
      $this->add_error(
          apply_filters( 'wplinktrade_insert_partner_error', __("Sorry, but something went wrong! Your submission was not successful. Please contact the site administrator!", 'wplinktrade')
        )
      );
    }
  }

  /**
   * Checks is a link partner is already in the database
   *
   * @access private
   * @return bool True on existing link partner, false on new partner
   */
  private function partner_exists() {

    $url = parse_url( $this->get_detail( 'site_url' ) );

    $args = array(
      'post_type'   => 'linktrade',
      'post_status' => 'any',
      'numberposts' => 1,
      'meta_query'  => array(
        array(
          'key'     =>  'site_url',
          'value'   =>  $url['host'],
          'compare' => 'LIKE'
        )
      )
    );

    $tradelinks = new WP_Query( $args );

    if ( $tradelinks->have_posts() )
      return true;
    else
      return false;
  }

  /**
   * Inserts a new partner into the database
   *
   * @access  private
   * @version 1.5.0
   * @since   1.0.0
   * @return void
   */
  private function insert_partner() {

    if ( 'yes' == $this->get_setting( 'auto_approve' ) ) {
      $post_status = 'publish';
    }
    else {
      $post_status = 'pending';
    }

    $post = array(
      'post_type'   => 'linktrade',
      'post_author' => 1,
      'post_status' => $post_status,
      'post_title'  => $this->get_detail( 'site_name' )
    );

    $post_id = wp_insert_post( $post );

    if ( $post_id ) {
      update_post_meta( $post_id, 'site_url', $this->get_detail('site_url') );
      update_post_meta( $post_id, 'link_title', $this->get_detail('link_title') );
      update_post_meta( $post_id, 'site_description', $this->get_detail('site_description') );
      update_post_meta( $post_id, 'link_type', $this->get_detail('link_type') );
      update_post_meta( $post_id, 'reciprocal_link', $this->get_detail('reciprocal_link') );
      update_post_meta( $post_id, 'reciprocal_link_required', $this->get_detail('reciprocal_link_required') );
      update_post_meta( $post_id, 'contact_name', $this->get_detail('contact_name') );
      update_post_meta( $post_id, 'contact_email', $this->get_detail('contact_email') );
      update_post_meta( $post_id, 'backlink_found', $this->get_detail('backlink') );

      // Add to category if enabled
      if ( 'yes' == $this->get_setting( 'categorize' ) ) {
        if ( $this->get_detail( 'link_category' ) && taxonomy_exists( 'linktrade_cat' )  ) {
          wp_set_object_terms( $post_id, intval( $this->get_detail( 'link_category' ) ), 'linktrade_cat' );
        }
      }

      // Update stats
      update_post_meta( $post_id, 'today_in', '0');
      update_post_meta( $post_id, 'total_in', '0');
      update_post_meta( $post_id, 'today_out', '0');
      update_post_meta( $post_id, 'total_out', '0');
      update_post_meta( $post_id, 'ratio', '0' );
      update_post_meta( $post_id, 'backlink', $this->get_detail('backlink') );

      // Allow users to add own custom fields to the post
      do_action( 'wplinktrade_insert_partner', $post_id );

      /*if ( $this->get_setting( 'allow_edit') == 'yes' ) {
        $this->set_detail( 'edit_key', $this->generate_edit_key() );
        update_post_meta( $post_id, 'edit_key', $this->get_detail( 'edit_key') );
      }*/

      // Upload banner if available
      if ( $this->get_detail( 'link_type' ) == 'image' ) {
        // Generate unique file name
        $file_info      = pathinfo( $_FILES['banner_file']['name'] );
        $wp_filetype    = wp_check_filetype( $_FILES['banner_file']['name'] );

        $upload_dir         = wp_upload_dir();
        $upload_dir['path'] = str_replace($upload_dir['subdir'], '/wplinktrade', $upload_dir['path'] );
        $pathdata['url']    = str_replace($upload_dir['subdir'], '/wplinktrade', $upload_dir['url'] );

        // Create upload directory if it doesn't exist
        if ( ! is_dir( $upload_dir['path'] ) ) {
          wp_mkdir_p ( $upload_dir['path'] );
        }

        $file_name      = wp_unique_filename( $upload_dir['path'] , $file_info['basename']);
        $abs_file_path  = $upload_dir['path']. '/' . $file_name;

        // Move the file to wplinktrade upload directory
        $result = move_uploaded_file( $_FILES['banner_file']['tmp_name'], $abs_file_path );

        // Delete the temp file
        @unlink($_FILES['banner_file']['tmp_name']);

        // Check image dimensions
        list( $width, $height, $type, $attr ) = @getimagesize( $abs_file_path );

        if ( 'gif' !== $file_info['extension'] && ( $width != $this->get_setting('banner_width') || $height != $this->get_setting('banner_height') ) ) {

          // We have to resize the image
          // Don't resize gifs because they can be animated
          $image = wp_get_image_editor( $abs_file_path );

          if ( ! is_wp_error( $image ) ) {

            $image->resize( $this->get_setting('banner_width'), $this->get_setting('banner_height'), true );
            $result = $image->save( $abs_file_path );

            /*if ( is_wp_error( $result ) ) {
              $this->log("Can't save resized image. Error: " . $result->get_error_message() );
            }*/
          }
          /*else {
            $this->log("Can't open image editor. Error: " . $image->get_error_message() );
          }*/
        }

        // Add file to media library
        $attachment = array(
          'guid'            => $upload_dir['url'] . '/' . basename( $file_name ),
          'post_mime_type'  => $wp_filetype['type'],
          'post_title'      => preg_replace('/\.[^.]+$/', '', basename( $file_name ) ),
          'post_content'    => '',
          'post_status'     => 'inherit'
        );

        $attach_id = wp_insert_attachment( $attachment, $abs_file_path, $post_id );
        set_post_thumbnail($post_id, $attach_id);
      }

      // Add post id to partner array
      $this->set_detail( 'id',  $post_id );

      return true;
    }

    // An error occured
    return false;
  }

  /**
   * Generates a unique edit key for each partner link
   *
   * @access private
   * @return void
   */
  /*private function generate_edit_key() {
   $uid   = uniqid("", true);
   $data  = $this->get_detail( 'site_url' ) . time() . $this->get_detail( 'post_id') . $this->get_detail( 'contact_email' );
   $data .= !empty( $_SERVER['REQUEST_TIME'] ) ? $_SERVER['REQUEST_TIME'] : rand();
   $data .= !empty( $_SERVER['HTTP_USER_AGENT'] ) ? $_SERVER['HTTP_USER_AGENT'] : 'wplt';
   $data .= !empty( $_SERVER['LOCAL_ADDR'] ) ? $_SERVER['LOCAL_ADDR'] : $this->get_detail( 'contact_name' );
   $data .= !empty( $_SERVER['REMOTE_ADDR'] ) ? $_SERVER['REMOTE_ADDR'] : wp_generate_password( 12 );

   $hash = strtoupper( hash( 'ripemd128', $uid . md5($data) ) );
   $guid = $this->get_detail( 'id' ) . substr($hash,  2,  6) . '-' . substr($hash,  8,  4) . '-' . substr($hash, 12,  4) . '-' . substr($hash, 16,  4) . '-' . substr($hash, 20, 6);

   return $guid;
  }*/

  /**
   * Sends notifications to site admin and to the partner if enabled
   *
   * @access private
   * @return void
   */
  private function send_notifications() {

    // Init mailer
    $this->mailer();

    if ( $this->get_setting( 'admin_notifications' ) == 'yes' ) {
      $this->email->notify_admin();
    }

    if ( $this->get_setting( 'partner_notifications' ) == 'yes' ) {
      $this->email->notify_partner();
    }
  }

  /**
   * Sends out a backlink check report
   *
   * @access public
   * @return void
   */
  public function send_report( $data = array() ) {
    $this->mailer();
    $this->email->send_report( $data );
  }

  /**
   * Email Class.
   *
   * @access private
   * @return WPLinkTrade_Emails
   */
  private function mailer() {

    if ( empty( $this->email ) ) {
      $this->email = new WPLinkTrade_Emails();
    }

    return $this->email;
  }

  /**
   * Validates the click
   *
   * @access private
   * @return bool True if valid click
   */
  private function is_valid( $direction ) {

    if ( ! $this->post_id ) return false;

    // Get user IP
    $ip = $this->get_ipaddress();
    if ( !$ip ) return false;

    $transient_name = $ip . '_' . $direction . '_' . $this->post_id;

    // Check if the transient is in the database.
    // If so, return false
    if ( get_transient( $transient_name ) ) {
      return false; // Invalid click
    }

    // Set new transient for 10 minutes to avoid cheating
    set_transient( $transient_name, true, 60*10 );

    // Valid click
    return true;
  }

  /**
   * Retrieves the user's IP Address
   *
   * @access private
   * @return string IP Address or FALSE
   */
  private function get_ipaddress() {

    if ( empty( $_SERVER["HTTP_X_FORWARDED_FOR"] ) ) {
      $ip_address = $_SERVER["REMOTE_ADDR"];
    }
    else {
      $ip_address = $_SERVER["HTTP_X_FORWARDED_FOR"];
    }

    if ( strpos( $ip_address, ',' ) !== false ) {
      $ip_address = explode(',', $ip_address);
      $ip_address = $ip_address[0];
    }

    $ip_address = esc_attr( $ip_address );

    if  ( empty( $ip_address) ) return false;

    return $ip_address;
  }

  /**
   * Try to find our link on users page
   *
   * @access public
   * @param string URL
   * @return bool True if a backlink has been found
   */
  public function check_backlink( $url = false ) {

    if ( ! $url ) {
      $url = $this->get_detail( 'reciprocal_link' );
    }

    // Get content from the remove URL
    $args = array(
      'sslverify' => false,
      'timeout'   => 30
    );

    $response = wp_remote_get( $url , $args );

    if ( ! is_wp_error( $response ) ) {
      $content = wp_remote_retrieve_body( $response );

      if ( strpos( $content, $this->get_setting( 'link_url' ) ) !== FALSE ) {
        return true;
      }

      //if ( preg_match( '@'.$this->get_setting( 'link_url' ).'@', $content ) )
        //return true;
    }
    else {
      // Something went wrong: System ERROR
      $this->add_error(
        apply_filters( 'wplinktrade_backlink_check_error',
          sprintf( __("Your reciprocal link can't be verified. Error: %s", 'wplinktrade'), $response->get_error_message() )
        )
      );
      return -1;
    }

    // Link not found
    return false;
  }

  /**
   * Checks if our backlink is still on partner sites.
   */
  function check_all_backlinks() {
    // Set time limit
    @set_time_limit(0);

    // Get all link partners
    $args = array(
      'post_type'       => 'linktrade',
      'posts_per_page'  => -1,
      'post_status'     => array( 'publish', 'pending' )
    );

    global $post;
    $partners = array();

    $tradelinks = new WP_Query( $args );

    if ( $tradelinks->have_posts() ) {
      while ( $tradelinks->have_posts() ) {
        $tradelinks->the_post();

        $reciprocal_link = get_post_meta( $post->ID, 'reciprocal_link', true );

        if ( $reciprocal_link ) {

          $result = $this->check_backlink( $reciprocal_link );

          if ( $result !== true ) {
            update_post_meta( $post->ID, 'backlink_found', false );

            if ( $result == -1 ) {
              $result_message = __("Backlink could not be checked due to an server issue. Please check your outbound connection settings!", 'wplinktrade');
            }
            else {
              $result_message = __("Backlink not found!", 'wplinktrade');
            }

            // Populate the array only if the backlink can't be found
            $partners[] = array(
              'name'      => get_the_title(),
              'url'       => get_post_meta( $post->ID, 'site_url', true ),
              'edit_link' => admin_url( 'post.php?post='.$post->ID.'&action=edit' ),
              'result'    => $result_message
            );
          }
          else {
            // Update Link partner
            update_post_meta( $post->ID, 'backlink_found', true );
          }
        }
      }
    }

    return $partners;
  }

  /**
   * Schedule the midnight event to reset daily stats
   */
  private function schedule_midnight_event() {

    if ( ! wp_next_scheduled( 'wplinktrade_midnight_event' ) ) {
      $timestamp = strtotime("tomorrow") + get_option( 'gmt_offset' ) * 60 * 60;
      wp_schedule_single_event( $timestamp, 'wplinktrade_midnight_event' );
    }
  }

  /**
   * Reset daily stats
   */
  public function midnight_event() {

    // Get all published links
    $query = array(
      'post_type'   => 'linktrade',
      'numberposts' => -1,
      'status'      => 'publish'
    );

    $posts = get_posts( $query );

    if ( !$posts ) return;

    foreach ( $posts as $post ) {
      update_post_meta( $post->ID, 'today_in', 0 );
      update_post_meta( $post->ID, 'today_out', 0 );
    }

    return;
  }

  /**
   * Init WPLinkTrade taxonomies
   *
   * @access private
   * @version 1.5.0
   * @since   1.0.0
   * @return void
   */
  private function init_taxonomy() {

    if ( post_type_exists( 'linktrade') ) return;

    register_post_type( 'linktrade',
      array(
        'labels' => array(
            'name'                => __( 'Links', 'wplinktrade' ),
            'singular_name'       => __( 'Link', 'wplinktrade' ),
            'menu_name'           => _x( 'WPLinkTrade', 'Admin menu name', 'wplinktrade' ),
            'add_new'             => __( 'Add Link', 'wplinktrade' ),
            'add_new_item'        => __( 'Add New Link', 'wplinktrade' ),
            'edit'                => __( 'Edit', 'wplinktrade' ),
            'edit_item'           => __( 'Edit Link', 'wplinktrade' ),
            'new_item'            => __( 'New Link', 'wplinktrade' ),
            'view'                => __( 'View Links', 'wplinktrade' ),
            'view_item'           => __( 'View Link', 'wplinktrade' ),
            'search_items'        => __( 'Search Links', 'wplinktrade' ),
            'not_found'           => __( 'No Links found', 'wplinktrade' ),
            'not_found_in_trash'  => __( 'No Links found in trash', 'wplinktrade' ),
            'parent'              => __( 'Parent Link', 'wplinktrade' )
          ),
        'description'         => __( 'This is where you can add new links.', 'wplinktrade' ),
        'public'              => true,
        'show_ui'             => true,
        'capability_type'     => 'post',
        'map_meta_cap'        => true,
        'publicly_queryable'  => true,
        'exclude_from_search' => true,
        'show_in_menu'        => true,
        'hierarchical'        => false,
        'rewrite'             => false,
        'query_var'           => true,
        'supports'            => array( 'title', 'thumbnail', 'custom-fields' ),
        'show_in_nav_menus'   => false,
        'menu_icon'           => $this->plugin_url . '/assets/images/wplt.png'
      )
    );

    if ( 'yes' == $this->get_setting( 'categorize' ) ) {
      register_taxonomy( 'linktrade_cat',
        array( 'linktrade' ),
        array(
            'hierarchical'          => true,
            'update_count_callback' => '_update_post_term_count',
            'label'                 => __( 'Link Categories', 'mapti' ),
            'labels'                => array(
              'name'                => __( 'Link Categories', 'mapti' ),
              'singular_name'       => __( 'Link Category', 'mapti' ),
              'menu_name'           => _x( 'Categories', 'Admin menu name', 'mapti' ),
              'search_items'        => __( 'Search Link Categories', 'mapti' ),
              'all_items'           => __( 'All Link Categories', 'mapti' ),
              'parent_item'         => __( 'Parent Link Category', 'mapti' ),
              'parent_item_colon'   => __( 'Parent Link Category:', 'mapti' ),
              'edit_item'           => __( 'Edit Link Category', 'mapti' ),
              'update_item'         => __( 'Update Link Category', 'mapti' ),
              'add_new_item'        => __( 'Add New Link Category', 'mapti' ),
              'new_item_name'       => __( 'New Link Category Name', 'mapti' )
            ),
            'show_ui'               => true,
            'query_var'             => true,
            'capabilities'          => array(
              'manage_terms'        => 'manage_categories',
              'edit_terms'          => 'manage_categories',
              'delete_terms'        => 'manage_categories',
              'assign_terms'        => 'edit_posts',
            ),
            'rewrite'               => array(
              'slug'                => _x( 'link-category', 'slug', 'mapti' ),
              'with_front'          => false,
              'hierarchical'        => true,
            ),
          )
      );
    }
  }

  /**
   * Add post thumbnail support to linktrade post type
   *
   * @version 1.4.1
   * @since   1.4.1
   * @access  public
   * @return  void
   */
  public function theme_setup() {
    add_theme_support( 'post-thumbnails', array( 'linktrade' ) );
  }

  /**
   * Registers a new image size for linktrade banners
   *
   * @access private
   * @return void
   */
  private function init_image_sizes() {
    $size = array();

    $size['width']  = $this->get_setting( 'banner_width' );
    if ( !$size['width'] ) $size['width'] = 100;

    $size['height']  = $this->get_setting( 'banner_height' );
    if ( !$size['height'] ) $size['height'] = 100;

    add_image_size( 'linktrade_banner', $size['width'], $size['height'], true );
  }

  /**
   * Removes all image sizes except the wplintrade size for linktrade banners
   *
   * @access public
   * @return mixed $image_sizes
   */
  public function remove_default_image_sizes( $image_sizes ) {

    $id = !empty( $_REQUEST['post_id'] ) ? $_REQUEST['post_id'] : false;

    if ( !$id ) return $image_sizes;

    if ( get_post_type( $id ) == 'linktrade' ) {
      return array('linktrade_banner');
    }
    else {
      $sizes = count ( $image_sizes );
      for ($i = 0; $i < $sizes; $i++) {
        if ( $image_sizes[$i] == 'linktrade_banner') {
          unset( $image_sizes[$i] );
          break;
        }
      }
    }

    return $image_sizes;
  }

  /**
   * Replaces the uploaded file with the resized file.
   *
   * @access public
   * @return mixed
   */
  public function replace_uploaded_image( $image_data ) {
    global $_wp_additional_image_sizes;

    $id = !empty( $_REQUEST['post_id'] ) ? $_REQUEST['post_id'] : false;

    if ( !$id ) return $image_data;

    if ( get_post_type( $id ) == 'linktrade' ) {
      $upload_dir = wp_upload_dir();
      $uploaded_image_location = $upload_dir['basedir'] . '/' .$image_data['file'];

      if ( !empty( $image_data['sizes']['linktrade_banner'] ) ) {
        $image_location = $upload_dir['path'] . '/'.$image_data['sizes']['linktrade_banner']['file'];
        unlink($uploaded_image_location);
        rename($image_location, $uploaded_image_location);
        $image_data['width'] = $image_data['sizes']['linktrade_banner']['width'];
        $image_data['height'] = $image_data['sizes']['linktrade_banner']['height'];
        unset( $image_data['sizes']['linktrade_banner'] );
      }
    }

    return $image_data;
  }

  /**
   * Counts incoming clicks
   */
  private function incoming() {
    global $wpdb;

    if ( is_admin() ) return;
    if ( empty( $_SERVER['HTTP_REFERER'] ) ) return;

    $referer  = parse_url( $_SERVER["HTTP_REFERER"] );
    $site     = parse_url( site_url() );

    if ( $referer['host'] == $site['host'] ) return;

    // Get post ID by host
    $this->post_id = $wpdb->get_var("SELECT post_id FROM ".$wpdb->postmeta." WHERE  meta_key = 'site_url' AND meta_value like '%".$referer['host']."%' LIMIT 1");

    if ( !$this->post_id ) return;

    // Is this click valid?
    if ( ! $this->is_valid( 'in' ) ) return;

    // Increment only if the link is published
    if ( get_post_status ( $this->post_id ) == 'publish' ) {
      $this->increment( array( 'today_in', 'total_in' ) );
    }
  }

  /**
   * Ajax Callback. Counts outgoing clicks
   */
  public function outgoing() {
    global $wpdb;

    if ( empty($_POST) || empty( $_POST['link'] ) ) return false;

    $link = esc_url_raw( $_POST['link'] );

    // Get Post ID by link
    $this->post_id = $wpdb->get_var("
      SELECT m.post_id FROM ".$wpdb->postmeta." AS m
      INNER JOIN ".$wpdb->posts." AS p ON m.post_id = p.ID
      WHERE m.meta_key = 'site_url'
      AND m.meta_value = '".$link."'
      AND p.post_status = 'publish'
      LIMIT 1
    ");

    if ( !$this->post_id ) return;

    if ( ! $this->is_valid( 'out' ) ) return;

    // Update Counts
    $this->increment( array( 'today_out', 'total_out' ) );
    die();
  }

  /**
   * Count incoming and outgoing clicks
   *
   * @access private
   * @param int Post ID
   * @param array Meta fields that should be incremented example: array( 'totady_in', 'total_in' )
   * @return void
   */
  private function increment( $counts = array() ) {

    if ( ! $this->post_id ) return;

    foreach ( $counts as $count ) {
      $value = (int) get_post_meta( $this->post_id, $count, true );
      $value++;
      update_post_meta( $this->post_id, $count, $value);
    }

    // Update the ratio fot this partner
    $this->update_ratio();
  }

  /**
   * Updates the IN/OUT Ratio
   *
   * @access private
   * @return void
   */
  private function update_ratio() {

    if ( ! $this->post_id ) return;

    $in  = (int) get_post_meta( $this->post_id , 'total_in', true );
    $out = (int) get_post_meta( $this->post_id , 'total_out', true );

    if ( $out )
      $ratio = ( $in / $out ) * 100;
    else
      $ratio = 100;

    $ratio = round( $ratio, 2 );
    update_post_meta( $this->post_id, 'ratio', $ratio );
  }

  /**
   * Change the banner upload directory
   *
  */
  public function upload_dir( $pathdata ) {
    $id = !empty( $_REQUEST['post_id'] ) ? $_REQUEST['post_id'] : false;
    if ( !$id ) return $pathdata;

    $parent = get_post( $id )->post_parent;

    if ( get_post_type( $id ) == 'linktrade' || get_post_type( $parent ) == 'linktrade' ) {
      $subdir = '/wplinktrade';
      $pathdata['path']   = str_replace($pathdata['subdir'], $subdir, $pathdata['path']);
      $pathdata['url']    = str_replace($pathdata['subdir'], $subdir, $pathdata['url']);
      $pathdata['subdir'] = str_replace($pathdata['subdir'], $subdir, $pathdata['subdir']);
    }

    return $pathdata;
  }

  /**
   * Register Widget Function
   *
   * @access public
   * @return void
   */
  public function register_widgets() {
    include_once( 'classes/widgets/class-wplinktrade-widget-trades.php' );

    // Register Widgets
    register_widget( 'WPLinkTrade_Widget_Trades' );
  }

  //__________________________________________________________________________
  // SETTINGS FUNCTIONS

  /**
   * Retrieves all settings
   *
   * @access public
   * @return array Settings array
   */
  public function get_settings() {

    if ( empty($this->settings) )
      $this->settings = get_option('wplinktrade');

    return $this->settings;
  }

  /**
   * Updates the current settings in the database.
   * Stores the current settings array in to the db.
   *
   * @access public
   * @return void
   */
  public function update_settings() {
    update_option( 'wplinktrade', $this->settings );
  }

  /**
   * Get a setting value
   *
   * @access public
   * @param string Setting name
   * @return mixed | false Setting value or false if the settings isn't set
   */
  public function get_setting( $setting ) {
    return !empty( $this->settings[ $setting ] ) ? $this->settings[ $setting ] : false;
  }

  /**
   * Updates the value of the given setting.
   * The updated values will not be stored in the database by calling this function
   *
   * @access public
   * @param string Settings name
   * @param mixed Settings value
   * @return void
   */
  public function set_setting( $setting, $value ) {
    $this->settings[ $setting ] = $value;
  }

  //__________________________________________________________________________
  // PARTNER DETAILS FUNCTIONS

  /**
   * Updates the given partner key with a new value
   *
   * @access private
   * @return void
   */
  private function set_detail( $key, $value ) {
    $this->partner[ $key ] = $value;
  }

  /**
   * Retrieves the given partner key
   *
   * @access public
   * @return mixed
   */
  public function get_detail( $key ) {
    if ( ! empty( $this->partner[ $key ] ) )
      return $this->partner[ $key ];
    else
      return false;
  }

  /**
   * Retrieves all partner details
   *
   * @access private
   * @return array
   */
  private function get_details() {
    return $this->partner;
  }

  //__________________________________________________________________________
  // ERROR / INFO MESSAGE FUNCTIONS

  /**
   * Add Message
   *
   * @access public
   * @return void
   */
  public function add_message( $message, $type = 'error' ) {
    $this->messages[] = array(
      'message' => $message,
      'type'    => $type
    );
  }

  /**
   * Adds a new error
   *
   * @access public
   * @return void
   */
  public function add_error( $message ) {
    $this->add_message( $message, 'error' );
  }

  /**
   * Adds a new info message
   *
   * @access public
   * @return void
   */
  public function add_info( $message ) {
    $this->add_message( $message, 'info' );
  }

  /**
   * Checks if there are error messages
   *
   * @access public
   * @return bool True if there are error messages available
   */
  public function have_messages() {
    return ( empty( $this->messages ) ) ? false : true;
  }

  /**
   * Retrieves all error messages
   *
   * @access public
   * @return void
   */
  public function get_messages() {
    return $this->messages;
  }

  //__________________________________________________________________________
  // INSTALLATION FUNCTIONS

  /**
   * Install upon activation
   *
   * @access public
   * @return void
   */
  public function activate() {

    $settings = $this->get_settings();

    if ( empty($settings)  ) {
      $this->settings = $this->default_settings();
      add_option( 'wplinktrade', $this->settings );
    }

    add_option( 'wplinktrade_version',  $this->version );
  }

  /**
   * Install / Update WPLinkTade Options
   *
   * @access public
   * @return void
   */
  public function install() {

    if ( ! get_option( 'wplinktrade_version') ) {
      $this->activate();
    }
    elseif ( get_option( 'wplinktrade_version') != $this->version ) {
      // Update options
      $this->settings = $this->get_settings();
      $default_settings = $this->default_settings();

      foreach ( $default_settings as $def_key => $def_value ) {
        if ( ! isset( $this->settings[ $def_key ] ) ) {
          $this->settings[ $def_key ] = $def_value;
        }
      }

      $this->update_settings();

      update_option( 'wplinktrade_version', $this->version );
    }
  }

  /**
   * Fired when plugin gets deactivated
   *
   * @access public
   * @return void
   */
  public function deactivate() {
    //delete_option('wplinktrade');
    $this->unschedule_events();
  }

  /**
   * Load default settings
   *
   * @access private
   * @return array default settings
   */
  private function default_settings() {

    $settings = array(
      'admin_notifications'     => 'yes',
      'partner_notifications'   => 'yes',
      'auto_approve'            => 'no',
      'reciprocal'              => 'yes',
      'description_required'    => 'no',
      'link_target'             => '_blank',
      'relation'                => 'none',
      'exchange_type'           => array( 'text'  => 'yes', 'image' => false ),
      'categorize'              => 'no',
      'banner_height'           => 100,
      'banner_width'            => 100,
      'link_url'                => site_url(),
      'link_text'               => get_bloginfo( 'name' ),
      'link_title'              => get_bloginfo( 'description' ),
      'banner_url'              => false,
      'use_css'                 => 'yes',
      'secure_key'              => md5( site_url() . get_option( 'admin_email' ) ),
      'use_recaptcha'           => 'no',
      'recaptcha_public_key'    => '',
      'recaptcha_private_key'   => ''
    );

    return $settings;
  }

  /**
   * Removes all scheduled tasks
   *
   * @access private
   * @return void
   */
  private function unschedule_events() {
    if ( wp_next_scheduled( 'wplinktrade_midnight_event' ) ) {
      wp_clear_scheduled_hook( 'wplinktrade_midnight_event' );
    }
  }

  //__________________________________________________________________________
  // DEBUG FUNCTIONS

  /**
   * Log messages into a log file
   *
   * @access private
   * @param string Message that should be logged.
   * @return void
   */
  public function log ( $message = '' ) {

    $logdir = $this->plugin_dir .'logs';

    if ( !file_exists($logdir) ) {
      // Create logging folder
      @mkdir($logdir, '0777');
    }

    if ( file_exists($logdir) ) {
      $logfile = $logdir . '/' . date('Y_m_d') . '_log.txt';

      // open or create a log file
      if ( !is_file($logfile) ) {
        // File doesn't exist. Create a log file
        $fp = fopen($logfile, 'w+');
      }
      else if ( is_writable($logfile) && is_file($logfile) ) {
        // Open existing file
        $fp = fopen($logfile, 'a+');
      }

      // Did we open a file?
      if ( $fp ) {
        // Log the message
        //$content = "\n\n";
        //$content .= "===========".date('l dS \of F Y h:i:s A')."===========";
        $content = "\n\n";
        $content .= $message;
        fwrite($fp,$content);
        fclose($fp);
      }
    }
  }
} // END class

// Init WPLinkTrade
$GLOBALS['wplt'] = new WPLinkTrade();
} // class_exists check